@echo off
title MediKiosk 3 one-time setup
cd /d "%~dp0"
echo Installing Python, Tesseract OCR and Poppler (needed to read scanned reports)...
winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements
winget install -e --id UB-Mannheim.TesseractOCR --accept-source-agreements --accept-package-agreements
winget install -e --id oschwartz10612.Poppler --accept-source-agreements --accept-package-agreements
python -m pip install --upgrade pillow pytesseract
echo.
echo Done. Close this window, open a NEW terminal, then run start-windows.bat
pause
