@echo off
title MediKiosk 3 server
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Install it from https://nodejs.org and run this again.
  pause
  exit /b 1
)
echo Starting MediKiosk on http://localhost:8787
start "" http://localhost:8787
node server\index.mjs
pause
