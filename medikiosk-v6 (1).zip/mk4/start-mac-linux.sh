#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed. Install it from https://nodejs.org and run this again."
  exit 1
fi
export PYTHON="${PYTHON:-python3}"
echo "Starting MediKiosk on http://localhost:${PORT:-8787}"
node server/index.mjs
