/*
 * ============================================================
 *  PUT YOUR AI KEY HERE  (only the owner / hospital IT does this)
 * ============================================================
 *
 * The patient must NEVER be asked for an API key. Paste the key once in this
 * file, restart the server, and the whole kiosk works for everybody. On the
 * home screen a patient can then only pick the model (or leave it on default).
 *
 * provider: 'groq' | 'gemini' | 'openai' | 'openrouter' | 'ollama'
 *   groq      -> free key from https://console.groq.com/keys        (fastest)
 *   gemini    -> https://aistudio.google.com/apikey
 *   openai    -> https://platform.openai.com/api-keys
 *   openrouter-> https://openrouter.ai/keys
 *   ollama    -> runs on this PC, NO key needed (keep apiKey empty)
 *
 * model: leave '' to use the recommended default for that provider.
 */
export const AI_SETUP = {
	provider: 'groq',
	apiKey: '',  // <-- paste your key inside these quotes
	model: '',             // e.g. 'llama-3.3-70b-versatile'  (optional)

	// true  = patients can only choose the model, the key stays hidden (recommended)
	// false = the key box is visible on the home screen as before
	lockKey: true,
};
