/*
 * MediKiosk AI brain.
 *
 * Everything that used to be a fixed script now goes through a language model:
 * identity checking, the whole interview, reading uploaded reports, and the
 * physician summary. There is no constant question list anywhere.
 */
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const cfgFile = path.join(here, 'ai-config.json');

// Providers rename and retire models often, so every provider carries a list of
// working models. The first one that answers is remembered.
const MODELS = {
  groq: ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'meta-llama/llama-4-scout-17b-16e-instruct', 'openai/gpt-oss-20b', 'gemma2-9b-it'],
  gemini: ['gemini-2.5-flash', 'gemini-2.0-flash', 'gemini-2.5-flash-lite', 'gemini-flash-latest'],
  openai: ['gpt-4o-mini', 'gpt-4.1-mini', 'gpt-4o'],
  openrouter: ['meta-llama/llama-3.3-70b-instruct', 'google/gemini-2.0-flash-001', 'openai/gpt-4o-mini'],
  ollama: ['llama3.1', 'llama3.2', 'qwen2.5', 'mistral'],
};

export const PRESETS = {
  groq: {label: 'Groq (free key, fastest)', kind: 'openai', baseUrl: 'https://api.groq.com/openai/v1', keyless: false},
  gemini: {label: 'Google Gemini', kind: 'gemini', baseUrl: 'https://generativelanguage.googleapis.com/v1beta', keyless: false},
  openai: {label: 'OpenAI', kind: 'openai', baseUrl: 'https://api.openai.com/v1', keyless: false},
  openrouter: {label: 'OpenRouter', kind: 'openai', baseUrl: 'https://openrouter.ai/api/v1', keyless: false},
  ollama: {label: 'Ollama (offline, on this PC)', kind: 'openai', baseUrl: 'http://localhost:11434/v1', keyless: true},
};

export function readConfig() {
  let saved = {};
  try { saved = JSON.parse(fs.readFileSync(cfgFile, 'utf8')) } catch {}
  const provider = String(process.env.AI_PROVIDER || saved.provider || '').trim();
  const preset = PRESETS[provider] || {};
  return {
    provider,
    apiKey: String(process.env.AI_API_KEY || saved.apiKey || '').trim(),
    model: String(process.env.AI_MODEL || saved.model || MODELS[provider]?.[0] || '').trim(),
    baseUrl: String(process.env.AI_BASE_URL || saved.baseUrl || preset.baseUrl || '').trim(),
    kind: preset.kind || 'openai',
    keyless: !!preset.keyless,
  };
}

export function writeConfig(input) {
  const provider = String(input.provider || '').trim();
  if (provider && !PRESETS[provider]) throw new Error('Unknown AI provider.');
  const cfg = {
    provider,
    apiKey: String(input.apiKey || '').trim(),
    model: String(input.model || MODELS[provider]?.[0] || '').trim(),
    baseUrl: String(input.baseUrl || PRESETS[provider]?.baseUrl || '').trim(),
  };
  fs.writeFileSync(cfgFile, JSON.stringify(cfg, null, 2));
  return cfg;
}

export function aiEnabled() {
  const c = readConfig();
  return !!(c.provider && c.baseUrl && (c.apiKey || c.keyless));
}

export function aiStatus() {
  const c = readConfig();
  return {
    enabled: aiEnabled(),
    provider: c.provider || null,
    label: PRESETS[c.provider]?.label || null,
    model: c.model || null,
    keySet: !!c.apiKey,
    providers: Object.entries(PRESETS).map(([id, p]) => ({id, label: p.label, model: MODELS[id]?.[0] || '', keyless: !!p.keyless})),
  };
}

function rememberModel(model) {
  try { const c = readConfig(); if (c.model !== model) writeConfig({...c, model}) } catch {}
}

async function withTimeout(promise, ms) {
  let timer;
  const guard = new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('The AI service took too long to reply.')), ms) });
  try { return await Promise.race([promise, guard]) } finally { clearTimeout(timer) }
}

const RETRYABLE = /does not exist|not found|no access|do not have access|decommission|deprecat|unsupported|not supported/i;
// Some providers reject their own JSON mode when a reply is long or truncated.
// In that case we simply ask again without JSON mode and parse the text ourselves.
const JSON_MODE_FAILED = /failed to validate json|json_validate_failed|response_format|json_object/i;

export async function chat(messages, options = {}) {
  const c = readConfig();
  if (!aiEnabled()) throw new Error('The AI brain is not connected yet.');
  const timeout = options.timeout || 45000;
  const wantJson = options.json !== false;
  const candidates = [c.model, ...(MODELS[c.provider] || []).filter(m => m !== c.model)].filter(Boolean);
  let lastError = 'The AI request failed.';

  for (const model of candidates) {
    if (c.kind === 'gemini') {
      const system = messages.filter(m => m.role === 'system').map(m => m.content).join('\n');
      const contents = messages.filter(m => m.role !== 'system')
        .map(m => ({role: m.role === 'assistant' ? 'model' : 'user', parts: [{text: m.content}]}));
      const res = await withTimeout(fetch(`${c.baseUrl}/models/${encodeURIComponent(model)}:generateContent`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json', 'x-goog-api-key': c.apiKey},
        body: JSON.stringify({
          contents,
          systemInstruction: system ? {parts: [{text: system}]} : undefined,
          generationConfig: {
            temperature: options.temperature ?? 0.25,
            maxOutputTokens: options.maxTokens || 1400,
            responseMimeType: wantJson ? 'application/json' : 'text/plain',
          },
        }),
      }), timeout);
      const data = await res.json().catch(() => ({}));
      if (res.ok) {
        rememberModel(model);
        return (data?.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('').trim();
      }
      lastError = data?.error?.message || `The AI request failed (HTTP ${res.status}).`;
      if (res.status !== 404 && !RETRYABLE.test(lastError)) break;
      continue;
    }

    const headers = {'Content-Type': 'application/json'};
    if (c.apiKey) headers.Authorization = `Bearer ${c.apiKey}`;
    const call = jsonMode => withTimeout(fetch(`${c.baseUrl}/chat/completions`, {
      method: 'POST', headers,
      body: JSON.stringify({
        model, messages,
        temperature: options.temperature ?? 0.25,
        max_tokens: options.maxTokens || 1400,
        ...(jsonMode ? {response_format: {type: 'json_object'}} : {}),
      }),
    }), timeout);

    let res = await call(wantJson);
    let data = await res.json().catch(() => ({}));
    if (!res.ok && wantJson && JSON_MODE_FAILED.test(data?.error?.message || '')) {
      res = await call(false);
      data = await res.json().catch(() => ({}));
    }
    if (res.ok) {
      rememberModel(model);
      return String(data?.choices?.[0]?.message?.content || '').trim();
    }
    lastError = data?.error?.message || `The AI request failed (HTTP ${res.status}).`;
    if (res.status !== 404 && !RETRYABLE.test(lastError)) break;
  }
  throw new Error(lastError);
}

function parseJson(text) {
  if (!text) return null;
  try { return JSON.parse(text) } catch {}
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fenced) { try { return JSON.parse(fenced[1]) } catch {} }
  const braces = text.match(/\{[\s\S]*\}/);
  if (braces) { try { return JSON.parse(braces[0]) } catch {} }
  return null;
}

export async function chatJson(messages, options = {}) {
  const raw = await chat(messages, {...options, json: true});
  const out = parseJson(raw);
  if (!out) throw new Error('The model replied in an unexpected format. Try another model.');
  return out;
}

export async function testConnection() {
  // Plain text on purpose: some providers reject a very short JSON-mode reply,
  // and this check only needs to prove that the key and the model work.
  const reply = await chat([
    {role: 'system', content: 'You are a connection test. Answer in one short word.'},
    {role: 'user', content: 'Reply with the single word: ready'},
  ], {json: false, maxTokens: 20, timeout: 30000});
  if (!reply) throw new Error('The model answered with nothing. Try another model.');
  return true;
}

/* ------------------------------------------------------------------ *
 * Shared clinical guardrails
 * ------------------------------------------------------------------ */

const LANGS = {en: 'English', hi: 'Hindi', mr: 'Marathi', bn: 'Bengali', ta: 'Tamil', te: 'Telugu', kn: 'Kannada', gu: 'Gujarati'};

const CORE = `You are the clinical intake intelligence of MediKiosk, a self-service kiosk in an Indian government AYUSH hospital (Ministry of AYUSH / All India Institute of Ayurveda).

Absolute rules:
- You never diagnose, never confirm a disease, never suggest, start, stop or change any medicine, dose or treatment.
- You only gather history and organise it for the physician, who makes every decision.
- Everything you produce is a draft that a physician must verify.
- Be warm, patient and respectful. Assume the person may be elderly, anxious, or unable to read well.
- No medical jargon. Short sentences.
- Output valid JSON only. No markdown, no commentary outside the JSON.`;

const JUDGEMENT = `Judgement rules (apply to every single answer, not just age):
- Read the answer against everything already known: age, gender, sex-specific plausibility, the reported complaint, earlier answers, and the uploaded reports.
- Reject and re-ask when an answer is impossible (a duration longer than the person has lived or beyond a human lifespan), self-contradictory, biologically impossible for that age or sex, a joke or sarcasm, random or meaningless words, a single letter, or an obvious speech-recognition mangling.
- Reject and re-ask when a number is out of any human range (for example a temperature of 200, a weight of 900 kg, 40 pregnancies).
- When you reject, do not record the answer and do not move on. Ask the same thing again, more simply, and gently say what confused you.
- Ask about one topic at a time, at most 22 words.
- Never repeat a question that is already answered.
- If the person denies a problem, believe them and move to a different area; never keep pushing the same denial.
- Follow the story rather than a checklist: what they said should decide what you ask next. A cough answer leads to sputum, fever, breathlessness and smoking; a period-related answer leads to cycle questions; a child leads to feeding and immunisation.
- Adapt to the person: fewer, simpler questions for a distressed or very old patient; more detail for a clear, talkative one.
- Cover, only when relevant to this person: the main problem, when and how it started, how it changes, severity, associated symptoms, past illness and surgery, current medicines, allergies, family history, sleep, appetite, bowel and urine, menstrual and obstetric history where applicable, occupation, tobacco, alcohol, diet, exercise, stress, and AYUSH context (digestion strength, bowel habit, thirst, sweating, sleep quality, daily routine, body build, temperament).
- If an emergency symptom appears (severe chest pain, breathing difficulty, stroke signs, fainting, heavy bleeding, poisoning, very high fever with confusion, self-harm thoughts), set urgent true, list the reason, and tell the person to alert hospital staff.`;

/* ------------------------------------------------------------------ *
 * 1. Identity screening
 * ------------------------------------------------------------------ */

export async function aiCheckIdentity({form, checksum, language}) {
  const lang = LANGS[language] || 'English';
  return chatJson([
    {role: 'system', content: CORE},
    {role: 'user', content: `A person is registering at the kiosk. Judge whether these details can belong to a real patient.

Submitted: ${JSON.stringify(form)}
Official ID checksum result from the server: ${JSON.stringify(checksum)}

Check for: fake or placeholder names (test, asdf, abc, random letters), an age that is not a plausible human age, an age that contradicts the stated details, a phone number that is not a plausible 10-digit Indian mobile, a name of numbers or symbols, and any ID number the server marked invalid. Do not reject unusual but real Indian names.

Return JSON:
{"ok": true,
 "problems": [{"field": "name|age|gender|phone|id", "message": "one short sentence in English telling the person what to fix"}],
 "messageForPatient": "one short line in ${lang}, empty if ok",
 "notes": "anything the front desk should know, or empty"}` },
  ], {maxTokens: 500, temperature: 0.1});
}

/* ------------------------------------------------------------------ *
 * 2. The interview: the AI decides every turn
 * ------------------------------------------------------------------ */

export async function aiTurn({patient, transcript, reports, record, language, answer, clarifyCount}) {
  const lang = LANGS[language] || 'English';
  const history = (transcript || []).map((t, i) => `${i + 1}. Q: ${t.question}\n   A: ${t.answer}`).join('\n');
  const docs = (reports || []).map(r => ({
    type: r.documentType, date: r.reportDate,
    values: (r.labValues || []).map(v => `${v.name} ${v.value} ${v.unit} (${v.status})`),
    results: (r.testResults || []).map(t => `${t.name}: ${t.result}`),
  }));

  return chatJson([
    {role: 'system', content: `${CORE}\n\n${JUDGEMENT}`},
    {role: 'user', content: `Patient: ${patient?.age ?? '?'} year old ${patient?.gender || 'person'}${patient?.name ? `, name ${patient.name}` : ''}. Preferred language: ${lang}.

Interview so far:
${history || '(nothing asked yet)'}

The answer you must judge right now: ${answer === undefined || answer === null || answer === '' ? '(none yet - this is the first question)' : JSON.stringify(String(answer))}
Times you already asked for clarification on this topic: ${clarifyCount || 0}${(clarifyCount || 0) >= 2 ? ' (stop asking again: note that the answer was unclear and move to a new area)' : ''}

Uploaded reports the patient has attached: ${docs.length ? JSON.stringify(docs).slice(0, 3000) : '(none)'}

Structured record built so far: ${JSON.stringify(record || {}).slice(0, 3000)}

Decide, from this specific situation, what to do next. Nothing is fixed: you choose the topic, the wording, the tap options and when the interview ends. End it when you genuinely have a usable history for the physician, which may be after 6 questions for a simple case or 20 for a complex one.

Also update the structured record with what you have learned, merging with what is already there.

Return JSON:
{"accepted": true,
 "needsClarification": false,
 "clarifyReason": "short reason the answer was not usable, or empty",
 "question": "the next question in English, empty if finished",
 "translated": "the same question in ${lang}",
 "chips": ["up to 4 very short tap answers, or empty array for an open answer"],
 "inputType": "text|number|choice|yesno",
 "topic": "short slug, e.g. cough-character or menstrual-history",
 "sectionLabel": "human label for the area being explored, e.g. Present illness",
 "progress": 0,
 "empathy": "one optional short caring line in ${lang}, or empty",
 "urgent": false,
 "urgentReasons": [],
 "noteForDoctor": "one short clinical observation worth flagging, or empty",
 "record": {"chiefComplaint": "", "hpi": "", "pastHistory": "", "medications": "", "allergies": "", "familyHistory": "", "personalHistory": "", "ayush": "", "other": ""},
 "finished": false}` },
  ], {maxTokens: 1200, temperature: 0.35});
}

/* ------------------------------------------------------------------ *
 * 3. Reading an uploaded document
 * ------------------------------------------------------------------ */

export async function aiReadReport({rawText, parsed, patient, language}) {
  const lang = LANGS[language] || 'English';
  return chatJson([
    {role: 'system', content: CORE},
    {role: 'user', content: `Text below was scanned by OCR from a document the patient uploaded. OCR mixes up characters, splits columns and drops units, so read it carefully and correct obvious misreadings. It may be a lab report, prescription, discharge summary, imaging report, vaccination card or a handwritten note.

Patient: ${patient?.age ?? '?'} year old ${patient?.gender || 'person'}.

--- BEGIN SCANNED TEXT ---
${String(rawText || '').slice(0, 14000)}
--- END SCANNED TEXT ---

A simple pattern matcher found: ${JSON.stringify({labValues: parsed?.labValues || [], testResults: parsed?.testResults || []}).slice(0, 3000)}

Read the document yourself and return the full corrected structure. Include every test, value and medicine you can actually see, including the ones the pattern matcher missed. Use age and sex appropriate reference ranges when the report does not print them, and say so in the reference field. Never invent a value that is not in the text. If the document is not medical, say so in documentType and leave the lists empty.

Return JSON:
{"documentType": "e.g. Complete blood count, Dengue serology, Prescription, Discharge summary, X-ray report, Not a medical document",
 "reportDate": "date printed on the document, or null",
 "labName": "lab, clinic or hospital name, or null",
 "referredBy": "doctor name, or null",
 "labValues": [{"name": "", "value": "", "unit": "", "reference": "", "status": "Above the usual reference range|Below the usual reference range|Within the usual reference range|Not compared"}],
 "testResults": [{"name": "", "result": "Positive|Negative|Inconclusive|Reactive|Non-reactive"}],
 "medicines": [{"name": "", "dose": "", "frequency": "", "duration": ""}],
 "impressions": ["lines the report itself states as impression or advice, quoted factually"],
 "doctorHighlights": ["short factual points the physician should notice first"],
 "followUpQuestions": ["questions the kiosk should ask the patient because of this document"],
 "patientExplanation": "3 simple sentences in ${lang} saying what this document contains, with no diagnosis and no advice",
 "summary": "one factual paragraph in English for the physician",
 "confidence": "high|medium|low",
 "ocrConcerns": ["parts that were unreadable or doubtful"]}` },
  ], {maxTokens: 2000, temperature: 0.1, timeout: 90000});
}

/* ------------------------------------------------------------------ *
 * 4. The physician-ready summary
 * ------------------------------------------------------------------ */

export async function aiSummary({patient, transcript, record, reports, notes, language}) {
  const lang = LANGS[language] || 'English';
  return chatJson([
    {role: 'system', content: CORE},
    {role: 'user', content: `Write the physician-ready intake summary for this patient from everything collected. Use only what is present; write "Not reported" where nothing was collected. Do not diagnose and do not recommend treatment. You may list what the physician might want to explore, phrased as questions.

Patient: ${JSON.stringify({age: patient?.age, gender: patient?.gender})}
Interview: ${JSON.stringify(transcript || []).slice(0, 8000)}
Running record: ${JSON.stringify(record || {}).slice(0, 3000)}
Kiosk notes: ${JSON.stringify(notes || []).slice(0, 1500)}
Documents: ${JSON.stringify((reports || []).map(r => ({
      type: r.documentType, date: r.reportDate,
      values: (r.labValues || []).map(v => `${v.name} ${v.value} ${v.unit} (${v.status})`),
      results: (r.testResults || []).map(t => `${t.name}: ${t.result}`),
      medicines: r.medicines || [],
      highlights: r.doctorHighlights || [],
    }))).slice(0, 6000)}

Return JSON:
{"headline": "one line a doctor can read in two seconds",
 "chiefComplaint": "",
 "hpi": "",
 "pastHistory": "",
 "surgicalHistory": "",
 "medications": "",
 "allergies": "",
 "familyHistory": "",
 "personalHistory": "",
 "reviewOfSystems": "",
 "ayushObservations": "",
 "reportFindings": ["one line per relevant finding, with the value"],
 "redFlags": ["urgent findings, empty if none"],
 "questionsForDoctor": ["things the physician may want to ask or examine"],
 "triage": "Routine|Priority|Immediate",
 "triageReason": "one short line",
 "completeness": 0,
 "gaps": ["history areas that are still missing"],
 "patientCopy": "a short, kind paragraph in ${lang} that the patient can read about what was collected"}` },
  ], {maxTokens: 2200, temperature: 0.2, timeout: 90000});
}

/* ------------------------------------------------------------------ *
 * 5. Doctor-side assistant over the whole queue
 * ------------------------------------------------------------------ */

export async function aiDoctorAsk({question, records}) {
  const slim = (records || []).slice(0, 40).map(r => ({
    token: r.token, id: r.id, age: r.patient?.age, gender: r.patient?.gender,
    status: r.status, triage: r.aiSummary?.triage,
    headline: r.aiSummary?.headline, complaint: r.aiSummary?.chiefComplaint,
    redFlags: r.aiSummary?.redFlags || [], findings: r.aiSummary?.reportFindings || [],
  }));
  return chatJson([
    {role: 'system', content: CORE},
    {role: 'user', content: `A physician is asking about the intake queue. Answer only from the data below; if it is not there, say so. Never diagnose or prescribe.

Queue: ${JSON.stringify(slim).slice(0, 9000)}

Question: ${JSON.stringify(String(question || ''))}

Return JSON:
{"answer": "a short, factual answer", "tokens": ["tokens of the patients referred to"], "caution": "any caveat, or empty"}` },
  ], {maxTokens: 900, temperature: 0.2});
}
