/*
 * MediKiosk 3 server.
 *
 * Zero npm dependencies: plain Node http, one Python helper for OCR.
 * There is no scripted question flow here. Every clinical decision about what
 * to ask, how to read a document and what to tell the physician comes from the
 * AI brain in ai.mjs. The server only validates IDs, runs OCR, and stores.
 */
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {AI_SETUP} from './ai-key.mjs';
import {
  aiEnabled, aiStatus, readConfig, writeConfig, testConnection,
  aiCheckIdentity, aiTurn, aiReadReport, aiSummary, aiDoctorAsk,
} from './ai.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.join(here, '..');
const pub = path.join(root, 'public');
const store = path.join(here, 'submissions.json');
const profileStore = path.join(here, 'profiles.json');
const PORT = Number(process.env.PORT || 8787);
const PYTHON = process.env.PYTHON || (process.platform === 'win32' ? 'python' : 'python3');
const DOCTOR_PIN = String(process.env.DOCTOR_PIN || '2026');

// The key belongs to the hospital, not to the patient. Whatever is written in
// server/ai-key.mjs is loaded once at start-up, so the kiosk is already
// connected when the first patient walks up to it.
const ownerKey = String(AI_SETUP?.apiKey || '').trim();
const ownerProvider = String(AI_SETUP?.provider || '').trim();
const keyLocked = AI_SETUP?.lockKey !== false;
function applyOwnerKey() {
  if (!ownerProvider) return;
  const current = readConfig();
  const keyless = ownerProvider === 'ollama';
  if (!ownerKey && !keyless) return;
  const changed = current.provider !== ownerProvider
    || (ownerKey && current.apiKey !== ownerKey)
    || (AI_SETUP.model && current.model !== AI_SETUP.model);
  if (!changed) return;
  try {
    writeConfig({provider: ownerProvider, apiKey: ownerKey, model: AI_SETUP.model || current.model || ''});
    console.log(`AI key loaded from server/ai-key.mjs (${ownerProvider}).`);
  } catch (e) { console.log('Could not apply server/ai-key.mjs: ' + e.message) }
}
applyOwnerKey();

// Adds the "is the key managed by the hospital?" flag to every status reply.
const status = () => ({...aiStatus(), keyManaged: keyLocked && (!!ownerKey || ownerProvider === 'ollama' || !!readConfig().apiKey)});

const send = (res, code, data) => {
  res.statusCode = code;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.end(JSON.stringify(data));
};

const readJson = req => new Promise((resolve, reject) => {
  let raw = '';
  req.on('data', c => { raw += c; if (raw.length > 4e6) reject(new Error('Request too large.')) });
  req.on('end', () => { try { resolve(raw ? JSON.parse(raw) : {}) } catch { reject(new Error('Malformed request body.')) } });
  req.on('error', reject);
});

/* ---------------- storage ---------------- */

function loadRecords() {
  try { return JSON.parse(fs.readFileSync(store, 'utf8')) } catch { return [] }
}
function saveRecords(list) {
  fs.writeFileSync(store, JSON.stringify(list, null, 2));
}

const SEEDED_DOCTORS = [
  ['DOC-SUY-001','Dr. Apoorva Choudhary','General & Laparoscopic Surgeon','','10:00 AM–2:00 PM'],
  ['DOC-SUY-002','Dr. C. P. Kothari','General & Laparoscopic Surgeon','','11:00 AM–3:00 PM'],
  ['DOC-SUY-003','Dr. Prashant Agrawal','General & Laparoscopic Surgeon','','9:30 AM–1:30 PM'],
  ['DOC-SUY-004','Dr. Vivek Sharma','General & Laparoscopic Surgeon','15+ years','4:00 PM–7:00 PM'],
  ['DOC-SUY-005','Dr. G. S. Malpani','General Physician','','10:00 AM–1:00 PM'],
  ['DOC-SUY-006','Dr. Mukesh Khapra','General Physician','','1:00 PM–4:00 PM'],
  ['DOC-SUY-007','Dr. Ashok Sethia','General Physician','','5:00 PM–8:00 PM'],
  ['DOC-SUY-008','Dr. A. B. Patel','General Physician','','9:00 AM–12:00 PM'],
  ['DOC-SUY-009','Dr. S. V. Rege','Neurosurgeon','','11:00 AM–2:00 PM'],
  ['DOC-SUY-010','Dr. Rakesh Gupta','Neurosurgeon','','3:00 PM–6:00 PM'],
  ['DOC-SUY-011','Dr. Piyush Panchariya','Neurosurgeon','15+ years','12:00 PM–3:00 PM'],
  ['DOC-SUY-012','Dr. Pravar Passi','Neuro Physician','','10:00 AM–1:00 PM'],
  ['DOC-SUY-013','Dr. Apoorva Puranik','Neuro Physician','','2:00 PM–5:00 PM'],
  ['DOC-SUY-014','Dr. Nipun Puranik','Neuro Physician','','4:00 PM–7:00 PM'],
  ['DOC-SUY-015','Dr. Archna Verma','Neuro Physician','','11:00 AM–2:00 PM'],
].map(([doctorId,name,specialty,experience,opd])=>({doctorId,name,specialty,experience,opd,hospital:'Suyash Hospital',practiceType:'Hospital',qualification:'MBBS / Specialist',consultationMode:'In person',preloaded:true}));
function loadProfiles(){
  try { const p=JSON.parse(fs.readFileSync(profileStore,'utf8')); p.patients ||= []; p.doctors ||= []; const ids=new Set(p.doctors.map(d=>d.doctorId)); for(const d of SEEDED_DOCTORS) if(!ids.has(d.doctorId)) p.doctors.push(d); return p } catch { return {patients:[],doctors:[...SEEDED_DOCTORS]} }
}
function saveProfiles(p){ fs.writeFileSync(profileStore,JSON.stringify(p,null,2)) }
function cleanId(v){ return String(v||'').trim().toUpperCase() }


/* ---------------- official ID checks ---------------- */

// Verhoeff checksum, the algorithm UIDAI uses for Aadhaar numbers.
const D = [
  [0,1,2,3,4,5,6,7,8,9],[1,2,3,4,0,6,7,8,9,5],[2,3,4,0,1,7,8,9,5,6],
  [3,4,0,1,2,8,9,5,6,7],[4,0,1,2,3,9,5,6,7,8],[5,9,8,7,6,0,4,3,2,1],
  [6,5,9,8,7,1,0,4,3,2],[7,6,5,9,8,2,1,0,4,3],[8,7,6,5,9,3,2,1,0,4],
  [9,8,7,6,5,4,3,2,1,0],
];
const P = [
  [0,1,2,3,4,5,6,7,8,9],[1,5,7,6,2,8,3,0,9,4],[5,8,0,3,7,9,6,1,4,2],
  [8,9,1,6,0,4,3,5,2,7],[9,4,5,3,1,2,6,8,7,0],[4,2,8,6,5,7,3,9,0,1],
  [2,7,9,3,8,0,6,4,1,5],[7,0,4,6,9,1,3,2,5,8],
];
const INV = [0,4,3,2,1,5,6,7,8,9];

function verhoeff(digits) {
  let c = 0;
  const rev = digits.split('').reverse();
  for (let i = 0; i < rev.length; i++) c = D[c][P[i % 8][Number(rev[i])]];
  return c === 0;
}

function checkId(type, value) {
  const digits = String(value || '').replace(/\D/g, '');
  if (type === 'aadhaar') {
    if (digits.length !== 12) return {valid: false, reason: 'An Aadhaar number must have 12 digits.'};
    if (digits[0] === '0' || digits[0] === '1') return {valid: false, reason: 'An Aadhaar number never starts with 0 or 1.'};
    if (!verhoeff(digits)) return {valid: false, reason: 'This Aadhaar number fails the official checksum, so it is not a real number.'};
    return {valid: true, reason: 'Passed the 12-digit Verhoeff checksum.'};
  }
  if (type === 'abha') {
    if (digits.length !== 14) return {valid: false, reason: 'An ABHA number must have 14 digits.'};
    return {valid: true, reason: 'Accepted as a 14-digit ABHA number.'};
  }
  return {valid: true, reason: 'No government ID was submitted.'};
}

/* ---------------- OCR helper ---------------- */

function runOcr(file, name) {
  return new Promise((resolve, reject) => {
    const py = spawn(PYTHON, [path.join(here, 'ocr.py'), file, name], {cwd: here});
    let out = '', err = '';
    py.stdout.on('data', d => { out += d });
    py.stderr.on('data', d => { err += d });
    py.on('error', () => reject(new Error(`Python was not found. Install Python 3 and make sure "${PYTHON}" works in a terminal.`)));
    py.on('close', () => {
      try {
        const parsed = JSON.parse(out);
        if (parsed.error) return reject(new Error(parsed.error));
        resolve(parsed);
      } catch {
        reject(new Error(err.trim().split('\n').pop() || 'The file could not be read.'));
      }
    });
  });
}

/* ---------------- static files ---------------- */

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon',
  '.woff2': 'font/woff2', '.json': 'application/json; charset=utf-8',
};

function serveStatic(res, route) {
  const rel = route === '/' ? 'index.html' : route.replace(/^\/+/, '');
  const file = path.join(pub, rel);
  if (!file.startsWith(pub) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    res.statusCode = 404;
    res.end('Not found');
    return;
  }
  res.setHeader('Content-Type', MIME[path.extname(file).toLowerCase()] || 'application/octet-stream');
  res.setHeader('Cache-Control', 'no-store');
  fs.createReadStream(file).pipe(res);
}

/* ---------------- server ---------------- */

const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Filename');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  if (req.method === 'OPTIONS') { res.statusCode = 204; return res.end() }

  const url = new URL(req.url, 'http://' + (req.headers.host || 'localhost'));
  const route = url.pathname;

  try {
    if (route === '/api/health') {
      return send(res, 200, {ok: true, python: PYTHON, submissions: loadRecords().length, ai: status()});
    }

    if (route === '/api/ai/status') return send(res, 200, status());

    if (route === '/api/ai/config' && req.method === 'POST') {
      const body = await readJson(req);
      try {
        const saved = readConfig();
        const key = String(body.apiKey || '').trim() || saved.apiKey;
        writeConfig({provider: body.provider, apiKey: key, model: body.model, baseUrl: body.baseUrl});
      } catch (e) { return send(res, 400, {error: e.message, ...status()}) }
      if (body.provider) {
        try { await testConnection() }
        catch (e) { return send(res, 400, {error: e.message, ...status()}) }
      }
      return send(res, 200, {saved: true, ...status()});
    }


    if (route === '/api/directory' && req.method === 'GET') {
      const p=loadProfiles();
      return send(res,200,{hospitals:[...new Set(p.doctors.map(d=>d.hospital).filter(Boolean))].sort(),doctors:p.doctors.sort((a,b)=>a.specialty.localeCompare(b.specialty)||a.name.localeCompare(b.name))});
    }
    if (route === '/api/patient/register' && req.method === 'POST') {
      const body=await readJson(req); const patient=body.patient||{};
      if(!patient.name||!patient.phone) return send(res,400,{error:'Name and mobile number are required.'});
      const p=loadProfiles(); const patientId=`MK-${Math.random().toString(36).slice(2,8).toUpperCase()}`;
      p.patients.push({patientId,patient,createdAt:new Date().toISOString()}); saveProfiles(p);
      return send(res,200,{saved:true,patientId});
    }
    if (route === '/api/patient/login' && req.method === 'POST') {
      const body=await readJson(req); const patientId=cleanId(body.patientId); const p=loadProfiles();
      const found=p.patients.find(x=>cleanId(x.patientId)===patientId); if(!found) return send(res,404,{error:'Patient ID not found. Check the ID or register as a new patient.'});
      const visits=loadRecords().filter(r=>cleanId(r.patientId)===patientId).sort((a,b)=>String(b.submittedAt).localeCompare(String(a.submittedAt)));
      const reports=[]; const seen=new Set(); for(const v of visits) for(const r of (v.reports||[])){const k=`${r.documentName}|${r.reportDate||''}|${r.rawText||''}`;if(!seen.has(k)){seen.add(k);reports.push(r)}}
      const doctors=p.doctors||[];
      const timeline=visits.map(v=>({
        id:v.id, token:v.token, submittedAt:v.submittedAt, status:v.status,
        chiefComplaint:v.aiSummary?.chiefComplaint||v.record?.chiefComplaint||'',
        triage:v.aiSummary?.triage||'', diagnosis:v.diagnosis||'', doctorNotes:v.doctorNotes||'',
        prescription:v.prescription||'', reviewedAt:v.reviewedAt||'',
        doctorName:(doctors.find(d=>cleanId(d.doctorId)===cleanId(v.assignedDoctorId))||{}).name||'',
        hospital:v.routing?.hospital||'', reportCount:(v.reports||[]).length,
      }));
      return send(res,200,{patientId,patient:found.patient,visitCount:visits.length,reports,visits:timeline,
        lastRecord:visits[0]?.record||{},lastAyush:visits[0]?.ayush||{},previousSummary:visits[0]?.aiSummary?.headline||''});
    }
    if (route === '/api/doctor/register' && req.method === 'POST') {
      const body=await readJson(req); if(!body.name||!body.phone||!body.qualification||!body.specialty||!body.hospital||!body.opd) return send(res,400,{error:'Please complete name, phone, qualification, specialization, workplace and OPD timings.'});
      const p=loadProfiles(); const doctorId=`DOC-${Math.random().toString(36).slice(2,8).toUpperCase()}`; const doctor={doctorId,...body,createdAt:new Date().toISOString()}; p.doctors.push(doctor); saveProfiles(p); return send(res,200,{saved:true,doctor});
    }
    if (route === '/api/doctor/profile' && req.method === 'POST') {
      const body=await readJson(req); const doctor=loadProfiles().doctors.find(d=>cleanId(d.doctorId)===cleanId(body.doctorId)); if(!doctor) return send(res,404,{error:'Doctor ID not found.'}); return send(res,200,{doctor});
    }

    if (route === '/api/doctor/login' && req.method === 'POST') {
      const body = await readJson(req);
      if (String(body.pin || '').trim() !== DOCTOR_PIN) {
        return send(res, 401, {error: 'That staff PIN is not correct.'});
      }
      return send(res, 200, {ok: true});
    }

    // Identity screening: server checksum first, then AI judgement on the rest.
    if (route === '/api/identity/check' && req.method === 'POST') {
      const body = await readJson(req);
      const form = body.form || {};
      const checksum = checkId(form.idType, form.idNumber);
      const problems = [];
      if (!checksum.valid) problems.push({field: 'id', message: checksum.reason});

      if (aiEnabled()) {
        try {
          const ai = await aiCheckIdentity({form, checksum, language: body.language || 'en'});
          const merged = [...problems, ...(ai.problems || []).filter(p => p.field !== 'id' || !checksum.valid === false)];
          const unique = [];
          for (const p of merged) if (!unique.some(u => u.field === p.field)) unique.push(p);
          return send(res, 200, {
            ok: unique.length === 0, engine: 'ai', problems: unique,
            messageForPatient: ai.messageForPatient || '', notes: ai.notes || '', checksum,
          });
        } catch (e) { console.error('AI identity check unavailable:', e.message) }
      }
      return send(res, 200, {ok: problems.length === 0, engine: 'checksum', problems, checksum});
    }

    // Every interview turn. No fixed stages: the AI owns the conversation.
    if (route === '/api/interview/turn' && req.method === 'POST') {
      const body = await readJson(req);
      if (!aiEnabled()) {
        return send(res, 503, {
          error: 'The AI brain is not connected, so the interview cannot run. Open AI settings on the home screen and connect a provider.',
          needsAi: true,
        });
      }
      try {
        const out = await aiTurn({
          patient: body.patient, transcript: body.transcript || [], reports: body.reports || [],
          record: body.record || {}, language: body.language || 'en',
          answer: body.answer, clarifyCount: body.clarifyCount || 0,
        });
        return send(res, 200, {engine: 'ai', ...out});
      } catch (e) {
        return send(res, 502, {error: `The AI brain could not answer: ${e.message}`});
      }
    }

    // Upload a document: OCR, then the AI reads it properly.
    if (route === '/api/report/read' && req.method === 'POST') {
      const name = decodeURIComponent(req.headers['x-filename'] || 'report.png');
      const ext = path.extname(name).toLowerCase();
      if (!['.png', '.jpg', '.jpeg', '.pdf', '.webp', '.bmp', '.tif', '.tiff'].includes(ext)) {
        return send(res, 415, {error: 'Please upload a PDF, JPG, PNG, WEBP or TIFF file.'});
      }
      const temp = path.join(os.tmpdir(), `medikiosk-${Date.now()}${ext}`);
      const chunks = []; let size = 0;
      for await (const chunk of req) {
        size += chunk.length;
        if (size > 25 * 1024 * 1024) return send(res, 413, {error: 'That file is larger than 25 MB. Please upload a smaller scan.'});
        chunks.push(chunk);
      }
      fs.writeFileSync(temp, Buffer.concat(chunks));
      try {
        const parsed = await runOcr(temp, name);
        if (!aiEnabled()) {
          return send(res, 200, {...parsed, engine: 'ocr-only', requiresVerification: true});
        }
        try {
          const ai = await aiReadReport({
            rawText: parsed.rawText, parsed,
            patient: JSON.parse(url.searchParams.get('patient') || '{}'),
            language: url.searchParams.get('lang') || 'en',
          });
          return send(res, 200, {
            documentName: parsed.documentName, rawText: parsed.rawText,
            ...ai, engine: 'ai', requiresVerification: true,
          });
        } catch (e) {
          console.error('AI report reading unavailable:', e.message);
          return send(res, 200, {...parsed, engine: 'ocr-only', aiError: e.message, requiresVerification: true});
        }
      } catch (e) {
        return send(res, 422, {error: e.message});
      } finally {
        fs.promises.unlink(temp).catch(() => {});
      }
    }

    // The physician-ready summary, written by the AI.
    if (route === '/api/summary' && req.method === 'POST') {
      const body = await readJson(req);
      if (!aiEnabled()) return send(res, 503, {error: 'The AI brain is not connected, so the summary cannot be written.', needsAi: true});
      try {
        const summary = await aiSummary({
          patient: body.patient, transcript: body.transcript || [], record: body.record || {},
          reports: body.reports || [], notes: body.notes || [], language: body.language || 'en',
        });
        return send(res, 200, {engine: 'ai', summary});
      } catch (e) {
        return send(res, 502, {error: `The AI brain could not write the summary: ${e.message}`});
      }
    }

    if (route === '/api/records' && req.method === 'POST') {
      const body = await readJson(req);
      const list = loadRecords();
      const record = {
        id: `REC-${Date.now().toString(36).toUpperCase()}`,
        token: `T-${String(list.length + 1).padStart(3, '0')}`,
        patientId: cleanId(body.patientId) || `MK-${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
        routing: body.routing || {},
        assignedDoctorId: body.routing?.doctorId || '',
        submittedAt: new Date().toISOString(),
        language: body.language || 'en',
        patient: body.patient || {},
        transcript: body.transcript || [],
        record: body.record || {},
        ayush: body.ayush || {},
        reports: body.reports || [],
        notes: body.notes || [],
        patientNote: body.patientNote || '',
        urgentReasons: body.urgentReasons || [],
        aiSummary: body.summary || null,
        consent: body.consent || {},
        status: 'Awaiting physician review',
      };
      list.unshift(record);
      saveRecords(list);
      const profiles=loadProfiles(); let profile=profiles.patients.find(x=>cleanId(x.patientId)===record.patientId);
      if(!profile){profile={patientId:record.patientId,patient:record.patient,createdAt:new Date().toISOString()};profiles.patients.push(profile)}else profile.patient={...profile.patient,...record.patient};
      profile.lastVisitAt=record.submittedAt; profile.reportCount=(record.reports||[]).length; saveProfiles(profiles);
      const assigned=(profiles.doctors||[]).find(d=>cleanId(d.doctorId)===cleanId(record.assignedDoctorId))||{};
      return send(res, 200, {saved: true, id: record.id, token: record.token, patientId:record.patientId,
        assignedDoctorId: record.assignedDoctorId, doctorName: assigned.name || '', specialty: assigned.specialty || record.routing?.specialty || '',
        hospital: assigned.hospital || record.routing?.hospital || '', opd: assigned.opd || '',
        submittedAt: record.submittedAt, status: record.status});
    }

    if (route === '/api/records' && req.method === 'GET') {
      const doctorId=cleanId(url.searchParams.get('doctorId')); const records=loadRecords();
      return send(res, 200, doctorId ? records.filter(r=>cleanId(r.assignedDoctorId)===doctorId) : records);
    }

    if (route === '/api/records/notes' && req.method === 'POST') {
      const body = await readJson(req);
      const list = loadRecords();
      const found = list.find(r => r.id === body.id);
      if (!found) return send(res, 404, {error: 'That record no longer exists.'});
      if (body.doctorNotes !== undefined) found.doctorNotes = String(body.doctorNotes);
      if (body.prescription !== undefined) found.prescription = String(body.prescription);
      if (body.diagnosis !== undefined) found.diagnosis = String(body.diagnosis);
      if (body.status !== undefined) found.status = String(body.status);
      found.reviewedAt = new Date().toISOString();
      saveRecords(list);
      return send(res, 200, {saved: true});
    }

    if (route === '/api/doctor/ask' && req.method === 'POST') {
      const body = await readJson(req);
      if (!aiEnabled()) return send(res, 503, {error: 'The AI brain is not connected.', needsAi: true});
      try {
        return send(res, 200, await aiDoctorAsk({question: body.question, records: loadRecords()}));
      } catch (e) {
        return send(res, 502, {error: e.message});
      }
    }

    if (route.startsWith('/api/')) return send(res, 404, {error: 'Unknown endpoint.'});
    return serveStatic(res, route);
  } catch (e) {
    return send(res, 500, {error: e.message || 'Unexpected server error.'});
  }
});

server.listen(PORT, () => {
  const st = status();
  console.log(`MediKiosk running at http://localhost:${PORT}`);
  console.log(st.enabled ? `AI brain: ${st.label} (${st.model})` : 'AI brain: not connected yet - open server/ai-key.mjs, paste your API key, then restart this server.');
});
