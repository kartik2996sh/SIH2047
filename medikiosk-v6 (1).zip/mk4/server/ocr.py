#!/usr/bin/env python3
"""MediKiosk report reader: real OCR + lab value structuring. No demo data."""
import sys, json, re, os, shutil, subprocess, tempfile


def have(cmd):
    return shutil.which(cmd) is not None


def pdf_text(path):
    if have('pdftotext'):
        try:
            out = subprocess.run(['pdftotext', '-layout', path, '-'], capture_output=True, text=True, timeout=120)
            if len(out.stdout.strip()) > 40:
                return out.stdout
        except Exception:
            pass
    return ''


def pdf_images(path):
    if not have('pdftoppm'):
        raise RuntimeError('pdftoppm (poppler-utils) is required to read scanned PDF files.')
    folder = tempfile.mkdtemp(prefix='medikiosk_')
    out = subprocess.run(['pdftoppm', '-png', '-r', '260', path, os.path.join(folder, 'page')], capture_output=True, text=True, timeout=300)
    pages = [os.path.join(folder, f) for f in sorted(os.listdir(folder)) if f.endswith('.png')]
    if not pages:
        raise RuntimeError('This PDF could not be opened. It may be damaged, password protected, or not a real PDF file. Try uploading a photo (JPG/PNG) of the report instead.')
    return pages


def ocr_image(path):
    if not have('tesseract'):
        raise RuntimeError('Tesseract OCR is not installed. Run setup-windows.bat (or install tesseract-ocr), then restart the terminal.')
    try:
        from PIL import Image, ImageEnhance, ImageFilter
        img = Image.open(path).convert('L')
        if img.width < 1700:
            img = img.resize((img.width * 2, img.height * 2))
        img = ImageEnhance.Contrast(img).enhance(1.9).filter(ImageFilter.SHARPEN)
        clean = tempfile.mktemp(suffix='.png')
        img.save(clean)
        path = clean
    except ImportError:
        pass
    best = ''
    for psm in ('6', '4', '11'):
        out = subprocess.run(['tesseract', path, 'stdout', '--psm', psm], capture_output=True, text=True, timeout=300)
        if len(out.stdout.strip()) > len(best.strip()):
            best = out.stdout
    return best


def extract_text(path):
    ext = os.path.splitext(path)[1].lower()
    if ext == '.txt':
        return open(path, encoding='utf-8', errors='ignore').read()
    if ext == '.pdf':
        text = pdf_text(path)
        if text:
            return text
        return '\n'.join(ocr_image(p) for p in pdf_images(path))
    return ocr_image(path)


MICRO = '/\u00b5L'

TESTS = [
    ('Hemoglobin', r'(?:ha?emoglobin|\bhb\b|\bhgb\b)\D{0,18}?([0-9]{1,2}(?:[.,][0-9]{1,2})?)', 'g/dL', 12.0, 17.5),
    ('Platelet count', r'(?:platelets?(?:\s*count)?|\bplt\b)\D{0,18}?([0-9]{1,3}(?:[,.][0-9]{3})*(?:\.[0-9]+)?)', MICRO, 150000, 450000),
    ('WBC / TLC', r'(?:total\s*leu[ck]ocyte\s*count|white\s*blood\s*cells?|\bwbc\b|\btlc\b)\D{0,18}?([0-9]{1,3}(?:[,.][0-9]{3})*(?:\.[0-9]+)?)', MICRO, 4000, 11000),
    ('RBC count', r'(?:red\s*blood\s*cells?|\brbc\b|erythrocyte)\D{0,18}?([0-9]{1,2}(?:[.,][0-9]{1,2})?)', 'million/\u00b5L', 4.2, 5.9),
    ('Hematocrit / PCV', r'(?:h[ae]matocrit|\bpcv\b|\bhct\b)\D{0,18}?([0-9]{1,2}(?:[.,][0-9]{1,2})?)', '%', 36.0, 50.0),
    ('MCV', r'\bmcv\b\D{0,15}?([0-9]{2,3}(?:[.,][0-9]{1,2})?)', 'fL', 80.0, 100.0),
    ('MCH', r'\bmch\b(?!c)\D{0,15}?([0-9]{1,3}(?:[.,][0-9]{1,2})?)', 'pg', 27.0, 33.0),
    ('MCHC', r'\bmchc\b\D{0,15}?([0-9]{1,2}(?:[.,][0-9]{1,2})?)', 'g/dL', 32.0, 36.0),
    ('RDW', r'\brdw(?:-cv)?\b\D{0,15}?([0-9]{1,2}(?:[.,][0-9]{1,2})?)', '%', 11.5, 14.5),
    ('Neutrophils', r'neutrophils?\D{0,18}?([0-9]{1,2}(?:[.,][0-9]{1,2})?)', '%', 40.0, 75.0),
    ('Lymphocytes', r'lymphocytes?\D{0,18}?([0-9]{1,2}(?:[.,][0-9]{1,2})?)', '%', 20.0, 45.0),
    ('Eosinophils', r'eosinophils?\D{0,18}?([0-9]{1,2}(?:[.,][0-9]{1,2})?)', '%', 1.0, 6.0),
    ('Monocytes', r'monocytes?\D{0,18}?([0-9]{1,2}(?:[.,][0-9]{1,2})?)', '%', 2.0, 10.0),
    ('ESR', r'\b(?:esr|erythrocyte\s*sedimentation)\b\D{0,18}?([0-9]{1,3})', 'mm/hr', 0, 20),
    ('CRP', r'\bcrp\b\D{0,18}?([0-9]{1,3}(?:[.,][0-9]{1,2})?)', 'mg/L', 0, 6),
    ('Fasting glucose', r'(?:fasting\s*(?:blood\s*)?(?:glucose|sugar)|\bfbs\b)\D{0,18}?([0-9]{2,3}(?:[.,][0-9]{1,2})?)', 'mg/dL', 70, 100),
    ('HbA1c', r'(?:hba1c|glycated\s*h[ae]moglobin)\D{0,18}?([0-9]{1,2}(?:[.,][0-9]{1,2})?)', '%', 4.0, 5.7),
    ('Creatinine', r'creatinine\D{0,18}?([0-9](?:[.,][0-9]{1,2})?)', 'mg/dL', 0.6, 1.3),
    ('Urea', r'\b(?:blood\s*)?urea\b\D{0,18}?([0-9]{1,3}(?:[.,][0-9]{1,2})?)', 'mg/dL', 15, 40),
    ('Uric acid', r'uric\s*acid\D{0,18}?([0-9]{1,2}(?:[.,][0-9]{1,2})?)', 'mg/dL', 3.5, 7.2),
    ('Total bilirubin', r'(?:total\s*)?bilirubin\D{0,18}?([0-9](?:[.,][0-9]{1,2})?)', 'mg/dL', 0.2, 1.2),
    ('SGOT / AST', r'(?:sgot|\bast\b)\D{0,18}?([0-9]{1,3}(?:[.,][0-9]{1,2})?)', 'U/L', 0, 40),
    ('SGPT / ALT', r'(?:sgpt|\balt\b)\D{0,18}?([0-9]{1,3}(?:[.,][0-9]{1,2})?)', 'U/L', 0, 41),
    ('TSH', r'\btsh\b\D{0,18}?([0-9]{1,2}(?:[.,][0-9]{1,2})?)', 'mIU/L', 0.4, 4.0),
    ('Total cholesterol', r'(?:total\s*)?cholesterol\D{0,18}?([0-9]{2,3}(?:[.,][0-9]{1,2})?)', 'mg/dL', 0, 200),
    ('Triglycerides', r'triglycerides?\D{0,18}?([0-9]{2,3}(?:[.,][0-9]{1,2})?)', 'mg/dL', 0, 150),
    ('Vitamin D', r'vitamin\s*d\D{0,20}?([0-9]{1,3}(?:[.,][0-9]{1,2})?)', 'ng/mL', 30, 100),
    ('Vitamin B12', r'(?:vitamin\s*b\s*-?12|cobalamin)\D{0,20}?([0-9]{2,4}(?:[.,][0-9]{1,2})?)', 'pg/mL', 200, 900),
    ('Blood glucose', r'(?:blood\s*)?(?:glucose|sugar)\D{0,15}?([0-9]{2,3}(?:[.,][0-9]{1,2})?)', 'mg/dL', 70, 140),
]

QUALITATIVE = [
    ('Dengue NS1 antigen', [r'dengue\s*ns1', r'ns1\s*(?:antigen)?']),
    ('Dengue IgM', [r'dengue\s*igm', r'igm[^\n]{0,14}dengue']),
    ('Dengue IgG', [r'dengue\s*igg', r'igg[^\n]{0,14}dengue']),
    ('Malaria parasite', [r'malaria\w*', r'plasmodium\s*\w*']),
    ('Typhoid / Widal', [r'widal', r'typhoid', r'salmonella\s*\w*']),
    ('COVID-19', [r'covid[\s-]*19', r'sars[\s-]*cov[\s-]*2']),
    ('Chikungunya', [r'chikungunya']),
    ('HIV', [r'\bhiv\b']),
    ('Hepatitis B (HBsAg)', [r'hbsag', r'hepatitis\s*b']),
    ('Urine pregnancy test', [r'pregnancy\s*test', r'\bupt\b', r'\bhcg\b']),
]
POSITIVE = ('positive', 'reactive', 'detected', 'present', 'seen')
NEGATIVE = ('negative', 'non reactive', 'non-reactive', 'nonreactive', 'not detected', 'absent', 'nil', 'not seen')
WORDS = '|'.join(POSITIVE + NEGATIVE)


def to_number(raw):
    txt = raw.replace(' ', '')
    if re.fullmatch(r'\d{1,3}(,\d{3})+(\.\d+)?', txt):
        txt = txt.replace(',', '')
    else:
        txt = txt.replace(',', '.')
    try:
        return float(txt)
    except ValueError:
        return None


def flag(value, low, high, unit):
    if value is None:
        return 'Not compared'
    if unit == MICRO and value < 1000:
        value = value * 1000 if value > 100 else value * 100000
    if value < low:
        return 'Below the usual reference range'
    if value > high:
        return 'Above the usual reference range'
    return 'Within the usual reference range'


def parse(text):
    flat = re.sub(r'[ \t]+', ' ', text)
    lowered = flat.lower()
    labs = []
    names = set()
    for name, pattern, unit, low, high in TESTS:
        match = re.search(pattern, lowered, re.I)
        if not match:
            continue
        number = to_number(match.group(1))
        if number is None:
            continue
        if name == 'Blood glucose' and any('glucose' in n.lower() for n in names):
            continue
        if name in names:
            continue
        names.add(name)
        labs.append({
            'name': name,
            'value': match.group(1).strip(),
            'unit': unit,
            'reference': '{} - {} {}'.format(low, high, unit),
            'status': flag(number, low, high, unit),
            'sourceLine': match.group(0).strip()[:140],
        })
    results = []
    for name, aliases in QUALITATIVE:
        found = None
        for alias in aliases:
            found = re.search(alias + r'[^\n\r]{0,60}?\b(' + WORDS + r')\b', lowered, re.I)
            if not found:
                found = re.search(r'\b(' + WORDS + r')\b[^\n\r]{0,40}?' + alias, lowered, re.I)
            if found:
                break
        if found:
            word = found.group(1).lower()
            results.append({
                'name': name,
                'result': 'Positive' if word in POSITIVE else 'Negative',
                'sourceLine': found.group(0).strip()[:140],
            })
    date = None
    for pattern in (r'\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})\b',
                    r'\b(\d{1,2}\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\w*\s+\d{4})\b',
                    r'\b(\d{4}-\d{2}-\d{2})\b'):
        hit = re.search(pattern, flat, re.I)
        if hit:
            date = hit.group(1)
            break
    kind = 'Medical report'
    if re.search(r'complete blood count|\bcbc\b|h[ae]mogram', lowered):
        kind = 'Complete blood count'
    elif re.search(r'dengue|malaria|widal|typhoid|serolog', lowered):
        kind = 'Serology / infection panel'
    elif re.search(r'lipid', lowered):
        kind = 'Lipid profile'
    elif re.search(r'thyroid|\btsh\b', lowered):
        kind = 'Thyroid profile'
    elif re.search(r'liver function|\blft\b', lowered):
        kind = 'Liver function test'
    elif re.search(r'kidney|renal|\bkft\b', lowered):
        kind = 'Kidney function test'
    elif re.search(r'discharge summary', lowered):
        kind = 'Discharge summary'
    elif re.search(r'prescription|\brx\b|tablet|\bcap\b', lowered):
        kind = 'Prescription'
    elif re.search(r'x[- ]?ray|ultrasound|\busg\b|\bmri\b|ct scan|sonograph', lowered):
        kind = 'Imaging report'
    return labs, results, date, kind


def summarize(kind, date, labs, results):
    parts = ['{}{} was read from the uploaded file.'.format(kind, ' dated ' + date if date else '')]
    if labs:
        parts.append('Values found: ' + '; '.join('{} {} {}'.format(x['name'], x['value'], x['unit']) for x in labs) + '.')
        outside = [x for x in labs if 'range' in x['status'] and not x['status'].startswith('Within')]
        if outside:
            parts.append('Outside the usual reference range: ' + '; '.join('{} {} {} ({})'.format(x['name'], x['value'], x['unit'], x['status'].lower()) for x in outside) + '.')
        else:
            parts.append('All matched numeric values fell inside the usual reference ranges.')
    if results:
        parts.append('Test results: ' + '; '.join('{} {}'.format(x['name'], x['result']) for x in results) + '.')
    if not labs and not results:
        parts.append('No supported laboratory values could be matched with confidence. Check the text below and enter values manually if needed.')
    parts.append('Every value must be checked against the original report by a clinician.')
    return ' '.join(parts)


def main():
    if len(sys.argv) < 2:
        print(json.dumps({'error': 'No file was given to the report reader.'}))
        return 1
    path = sys.argv[1]
    try:
        text = extract_text(path)
    except Exception as exc:
        print(json.dumps({'error': str(exc)}))
        return 1
    if not text.strip():
        print(json.dumps({'error': 'No readable text was found. Retake the photo in bright light, keep the page flat, and avoid blur.'}))
        return 1
    labs, results, date, kind = parse(text)
    print(json.dumps({
        'documentName': os.path.basename(sys.argv[2] if len(sys.argv) > 2 else path),
        'documentType': kind,
        'reportDate': date,
        'labValues': labs,
        'testResults': results,
        'rawText': text.strip()[:20000],
        'summary': summarize(kind, date, labs, results),
        'requiresVerification': True,
    }, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    sys.exit(main())
