# Turning the MediKiosk AI brain on

MediKiosk 3 has **no scripted questions**. The AI runs the identity check, the whole
interview, the report reading, the summary and the doctor's assistant. So the AI must
be connected before an intake can start.

Open the site → **I am a doctor or hospital staff** → PIN `2026` → **Settings**.

## Option 1 — Groq (free key, fastest)

1. Go to <https://console.groq.com/keys> and create a key (starts with `gsk_`).
2. Provider: **Groq (free key, fastest)**, paste the key, leave the model blank.
3. Save and test connection.

If a model name is retired, MediKiosk automatically tries the next one
(`llama-3.3-70b-versatile`, `llama-3.1-8b-instant`, `llama-4-scout`, `gpt-oss-20b`, `gemma2-9b-it`).

## Option 2 — Google Gemini

1. Create a key at <https://aistudio.google.com/apikey>.
2. Provider: **Google Gemini**, leave the model blank (defaults to `gemini-2.5-flash`).

Never share a screenshot of your key. If you already did, delete that key and make a new one.

## Option 3 — OpenAI or OpenRouter

Paste the key from <https://platform.openai.com/api-keys> or <https://openrouter.ai/keys>.

## Option 4 — Ollama (offline, no key, runs on this PC)

```bash
# install from https://ollama.com, then
ollama pull llama3.1
```

Provider: **Ollama (offline, on this PC)**. No key needed. Good for a demo with no internet.

## Environment variables instead of the UI

```bash
AI_PROVIDER=groq AI_API_KEY=gsk_xxx node server/index.mjs
```

## Reading scanned reports

The AI reads the text that OCR extracts, so install OCR once:

- Windows: run `setup-windows.bat`
- macOS: `brew install tesseract poppler`
- Ubuntu: `sudo apt install tesseract-ocr poppler-utils`

Check with `tesseract --version`. PDFs with real text work without Tesseract.

## Troubleshooting

| Message | Fix |
| --- | --- |
| `model ... does not exist` | Leave the model box blank so the fallback list is used. |
| `is not found for API version v1beta` | Gemini model retired — blank model box, or use `gemini-2.5-flash`. |
| `401 / invalid api key` | Re-copy the key, no spaces. |
| `fetch failed` | This computer has no internet, or a firewall is blocking it. Use Ollama. |
| `Tesseract OCR is not installed` | Run the OCR install above and restart the terminal. |
