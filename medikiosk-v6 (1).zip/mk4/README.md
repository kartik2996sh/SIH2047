# MediKiosk 3 — AI clinical intake (Ministry of AYUSH / AIIA)

A working website with a real backend. **There is no fixed question flow anywhere.**
The AI decides every question, judges every answer, reads every uploaded report and
writes the physician summary. One front end contains persistent patient and doctor profiles, plus two access modes:

- **Patient access** — identity check, consent, AI conversation (voice or touch), document scanning, review, submit.
- **Doctor / hospital access** — staff PIN, patient queue, patient view, document viewer, analytics, AI assistant, AI settings.

## Run it

### Windows
1. Double-click `setup-windows.bat` once (installs Python, Tesseract OCR, Poppler).
2. Double-click `start-windows.bat`.
3. Open <http://localhost:8787>.

### macOS / Linux
```bash
bash start-mac-linux.sh
```

Requires Node.js 18+. Python + Tesseract are only needed for reading scanned images.

## Turn the AI brain on (required)

Open the site → **I am a doctor or hospital staff** → PIN `2026` → **Settings** →
choose a provider, paste the key, **Save and test connection**.
Details and free options are in `AI-SETUP.md`. Without this the interview will
refuse to run instead of falling back to canned questions.

## Files

| File | What it does |
| --- | --- |
| `server/index.mjs` | HTTP server and all API routes. No question list, no stages. |
| `server/ai.mjs` | The AI brain: identity check, interview turn, report reading, summary, doctor Q&A. |
| `server/ocr.py` | Extracts text from PDFs and photos so the AI can read them. |
| `public/index.html` | Page shell, header, accessibility controls. |
| `public/app.js` | Both access modes, voice, uploads, doctor console. |
| `public/i18n.js` | Languages and dependency-free SVG charts. |
| `public/app.css` | New palette and animations. |
| `server/submissions.json` | The hospital queue (created on first submission). |
| `server/ai-config.json` | Your saved provider and key (created when you save settings). |

## Settings

| Variable | Default | Meaning |
| --- | --- | --- |
| `PORT` | `8787` | Server port |
| `DOCTOR_PIN` | `2026` | Staff console PIN |
| `PYTHON` | `python` / `python3` | Python used for OCR |
| `AI_PROVIDER` / `AI_API_KEY` / `AI_MODEL` | — | Override the saved AI config |

## Safety

AI never diagnoses, never confirms a disease and never prescribes. Everything it
produces is labelled a draft; the physician verifies it in the console.


## Connected profile flow

- New patients receive a `MK-...` ID; returning patients restore prior reports and follow-up context.
- New doctors receive a `DOC-...` ID; 15 Suyash Hospital specialists are preloaded and sorted by specialty.
- Before submission, patients choose hospital, specialty and doctor. Queues are filtered by assigned doctor.
- Profile data is saved in `server/profiles.json`. The AI provider, prompts and integration in `server/ai.mjs` remain unchanged.
