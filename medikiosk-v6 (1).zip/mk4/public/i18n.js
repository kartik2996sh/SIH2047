/* Languages and small helpers shared by the app. */
window.MK = (function () {
  const LANGS = [
    ['en', 'English', 'en-IN'],
    ['hi', 'हिन्दी', 'hi-IN'],
    ['mr', 'मराठी', 'mr-IN'],
    ['bn', 'বাংলা', 'bn-IN'],
    ['ta', 'தமிழ்', 'ta-IN'],
    ['te', 'తెలుగు', 'te-IN'],
    ['kn', 'ಕನ್ನಡ', 'kn-IN'],
    ['gu', 'ગુજરાતી', 'gu-IN'],
  ];

  const T = {
    en: {
      tagline: 'AI clinical intake',
      heroTitle: 'Your story. Your history. Better care.',
      heroSub: 'Speak in your own language, upload your old reports, and MediKiosk prepares a clear history for your doctor.',
      patient: 'I am a patient',
      patientSub: 'Answer a few spoken questions and upload your reports. Nothing is fixed — the questions follow whatever you say.',
      doctor: 'I am a doctor or hospital staff',
      doctorSub: 'Open the clinical queue, read the AI intake summary and verify it before the consultation.',
      speak: 'Tap the microphone to speak',
      listening: 'Listening… speak now',
      send: 'Send',
      repeat: 'Repeat question',
      disclaimer: 'AI-generated information is a draft for clinical review and does not replace a doctor\'s judgment.',
    },
    hi: {
      tagline: 'एआई क्लिनिकल इनटेक',
      heroTitle: 'आपकी बात, आपका इतिहास, बेहतर इलाज।',
      heroSub: 'अपनी भाषा में बोलिये, पुरानी रिपोर्ट डालिये — MediKiosk डॉक्टर के लिए साफ़ इतिहास तैयार कर देगा।',
      patient: 'मैं मरीज़ हूँ',
      patientSub: 'कुछ सवालों के जवाब बोलिये और रिपोर्ट अपलोड कीजिये। सवाल आपके जवाब के हिसाब से बदलते हैं।',
      doctor: 'मैं डॉक्टर या अस्पताल स्टाफ़ हूँ',
      doctorSub: 'मरीज़ों की सूची खोलिये, एआई का ड्राफ़्ट पढ़िये और जाँच कर पुष्टि कीजिये।',
      speak: 'बोलने के लिए माइक दबाइये',
      listening: 'सुन रहे हैं… अब बोलिये',
      send: 'भेजें',
      repeat: 'सवाल दोहराइये',
      disclaimer: 'एआई से बनी जानकारी केवल ड्राफ़्ट है, डॉक्टर की जाँच ज़रूरी है।',
    },
  };

  const t = (lang, key) => (T[lang] && T[lang][key]) || T.en[key] || '';
  const locale = lang => (LANGS.find(l => l[0] === lang) || LANGS[0])[2];

  /* Tiny dependency-free SVG charts for the analytics tab. */
  const COLORS = ['#0A4174', '#4E8EA2', '#7BBDE8', '#49769F', '#6EA2B3', '#5B4B8A', '#B4761E'];

  function bars(data, height = 190) {
    const max = Math.max(1, ...data.map(d => d[1]));
    const w = 100 / Math.max(1, data.length);
    return `<svg viewBox="0 0 100 ${height / 2}" style="width:100%;height:${height}px" role="img">
      ${data.map(([label, value], i) => {
        const h = (value / max) * (height / 2 - 16);
        return `<g>
          <rect x="${i * w + w * 0.2}" y="${height / 2 - 12 - h}" width="${w * 0.6}" height="${h}" rx="1.6" fill="${COLORS[i % COLORS.length]}">
            <animate attributeName="height" from="0" to="${h}" dur="0.7s" fill="freeze" />
            <animate attributeName="y" from="${height / 2 - 12}" to="${height / 2 - 12 - h}" dur="0.7s" fill="freeze" />
          </rect>
          <text x="${i * w + w * 0.5}" y="${height / 2 - 4}" font-size="3" text-anchor="middle" fill="#7C97AE">${label}</text>
          <text x="${i * w + w * 0.5}" y="${height / 2 - 15 - h}" font-size="3.4" text-anchor="middle" fill="#04182B">${value}</text>
        </g>`;
      }).join('')}
    </svg>`;
  }

  function donut(data) {
    const total = data.reduce((s, d) => s + d[1], 0) || 1;
    let acc = 0;
    const arcs = data.map(([, value], i) => {
      const frac = value / total;
      const seg = `${frac * 100} ${100 - frac * 100}`;
      const el = `<circle r="15.9" cx="21" cy="21" fill="transparent" stroke="${COLORS[i % COLORS.length]}"
        stroke-width="6" stroke-dasharray="${seg}" stroke-dashoffset="${25 - acc * 100}" />`;
      acc += frac;
      return el;
    }).join('');
    return `<div class="row" style="gap:20px">
      <svg viewBox="0 0 42 42" style="width:150px;height:150px">${arcs}</svg>
      <div>${data.map(([label, value], i) =>
        `<div class="row" style="gap:8px"><span style="width:11px;height:11px;border-radius:3px;background:${COLORS[i % COLORS.length]}"></span>
        <span class="tiny"><b style="color:#04182B">${value}</b> ${label}</span></div>`).join('')}</div>
    </div>`;
  }

  return {LANGS, T, t, locale, bars, donut, COLORS};
})();
