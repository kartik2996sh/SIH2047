/*
 * Whole-page translation.
 *
 * The screens are written in English. After every render this file walks the
 * page and swaps any known English phrase for the chosen language, so a
 * patient who picks हिन्दी sees the entire website in Hindi - headings,
 * buttons, labels, placeholders and helper text.
 *
 * Only exact phrases listed below are replaced, so a patient's own words, IDs,
 * doctor names and report values are never touched.
 */
(function () {
  const hi = {
    // header, footer, shell
    'AI clinical intake': 'एआई क्लिनिकल इनटेक',
    'Choose language': 'भाषा चुनिये',
    'Larger text': 'बड़ा अक्षर',
    'High contrast': 'ज़्यादा कंट्रास्ट',
    'Help': 'मदद',
    'Settings': 'सेटिंग',
    'Checking…': 'जाँच हो रही है…',
    'Connected': 'जुड़ा हुआ',
    'Backend offline': 'सर्वर बंद है',
    'MediKiosk is an intake assistant. Every AI-generated draft needs physician verification.':
      'MediKiosk केवल जानकारी लेने में मदद करता है। एआई का हर ड्राफ़्ट डॉक्टर की जाँच के बाद ही मान्य है।',
    'Temporary session data is cleared after submission.': 'अस्थायी सेशन डेटा भेजने के बाद मिटा दिया जाता है।',

    // landing
    'Connected care · one secure health journey': 'जुड़ी हुई देखभाल · एक सुरक्षित स्वास्थ्य यात्रा',
    'Smarter intake.': 'समझदार इनटेक।',
    'More time for care.': 'इलाज के लिए ज़्यादा समय।',
    'Register once, keep your reports, talk to the same AI intake, and securely reach the right hospital specialist.':
      'एक बार रजिस्टर कीजिये, रिपोर्ट सुरक्षित रहेंगी, हर बार वही एआई बात करेगा और सही विशेषज्ञ तक आपकी जानकारी पहुँचेगी।',
    'Open health portal': 'हेल्थ पोर्टल खोलिये',
    'See how it works ↓': 'यह कैसे काम करता है ↓',
    '24/7 AI intake': '24/7 एआई इनटेक',
    'Verified doctors': 'सत्यापित डॉक्टर',
    'Reports stay linked': 'रिपोर्ट जुड़ी रहती हैं',
    'Physician reviewed': 'डॉक्टर द्वारा जाँचा गया',
    'Simple and connected': 'आसान और जुड़ा हुआ',
    'From health concern to the right doctor': 'तकलीफ़ से सही डॉक्टर तक',
    'Care network': 'देखभाल नेटवर्क',
    'Specialists, organised by expertise': 'विशेषज्ञ, विभाग के अनुसार',
    'Designed for continuity': 'निरंतर देखभाल के लिए',
    'Returning patients do not start from zero': 'पुराने मरीज़ को दोबारा शुरू से नहीं बताना पड़ता',
    'Your documents stay with your ID': 'आपके दस्तावेज़ आपकी आईडी के साथ रहते हैं',
    'Ready when you are': 'जब आप तैयार हों',
    'Start your connected care journey': 'अपनी देखभाल यात्रा शुरू कीजिये',
    'Preloaded specialists': 'पहले से जुड़े विशेषज्ञ',
    'Supported languages': 'उपलब्ध भाषाएँ',
    'Physician verification': 'डॉक्टर द्वारा पुष्टि',

    // portal gate
    'Choose your portal': 'अपना पोर्टल चुनिये',
    'Continue as patient or doctor': 'मरीज़ या डॉक्टर के रूप में आगे बढ़िये',
    'I am a patient': 'मैं मरीज़ हूँ',
    'I am a doctor or hospital staff': 'मैं डॉक्टर या अस्पताल स्टाफ़ हूँ',
    'Patient login': 'मरीज़ लॉगिन',
    'Doctor login': 'डॉक्टर लॉगिन',
    'Doctor / staff sign in': 'डॉक्टर / स्टाफ़ लॉगिन',
    'Doctor registration': 'डॉक्टर रजिस्ट्रेशन',
    'Secure access': 'सुरक्षित प्रवेश',
    'Hospital access': 'अस्पताल प्रवेश',
    'Returning patient': 'पुराने मरीज़',
    'I am a new patient': 'मैं नया मरीज़ हूँ',
    'I have visited before': 'मैं पहले आ चुका/चुकी हूँ',
    'Login': 'लॉगिन',
    'Register doctor': 'डॉक्टर रजिस्टर कीजिये',
    'Create your professional profile': 'अपनी प्रोफ़ाइल बनाइये',
    'Open your clinical console': 'अपना क्लिनिकल कंसोल खोलिये',
    'Open clinical console': 'क्लिनिकल कंसोल खोलिये',
    'Restore my profile': 'मेरी प्रोफ़ाइल वापस लाइये',
    'Choose portal': 'पोर्टल चुनिये',

    // steps
    'Identify': 'पहचान',
    'Consent': 'सहमति',
    'Converse': 'बातचीत',
    'Ayurveda profile': 'आयुर्वेद प्रोफ़ाइल',
    'Medical documents': 'मेडिकल दस्तावेज़',
    'My history': 'मेरा इतिहास',
    'Review': 'जाँच',
    'Complete': 'पूरा',
    'Step 1': 'चरण 1',
    'Step 2': 'चरण 2',
    'Step 3': 'चरण 3',
    'Step 4': 'चरण 4',
    'Step 5': 'चरण 5',
    'Step 6': 'चरण 6',

    // identify / consent
    'Who is visiting today?': 'आज कौन आया है?',
    'Full name': 'पूरा नाम',
    'Age': 'उम्र',
    'Gender': 'लिंग',
    'Male': 'पुरुष',
    'Female': 'महिला',
    'Other': 'अन्य',
    'Mobile number': 'मोबाइल नंबर',
    'ID type': 'आईडी का प्रकार',
    'ID number': 'आईडी नंबर',
    'Continue': 'आगे बढ़िये',
    'Back': 'वापस',
    'Home': 'होम',
    'Your consent, in plain words': 'आपकी सहमति, आसान शब्दों में',
    'Consent for today\u2019s visit': 'आज की विज़िट के लिए सहमति',
    'I agree, continue': 'मैं सहमत हूँ, आगे बढ़िये',
    '🔊 Read this aloud': '🔊 यह पढ़कर सुनाइये',
    'Read this aloud': 'पढ़कर सुनाइये',

    // interview
    'Tell me what is happening': 'बताइये क्या तकलीफ़ है',
    'Tap the microphone to speak': 'बोलने के लिए माइक दबाइये',
    'Listening… speak now': 'सुन रहे हैं… अब बोलिये',
    'Send': 'भेजें',
    'Repeat question': 'सवाल दोहराइये',
    'Yes': 'हाँ',
    'No': 'नहीं',
    'Not sure': 'पता नहीं',
    'Skip to my reports →': 'सीधे रिपोर्ट पर जाइये →',
    '← Back to questions': '← सवालों पर वापस',
    'Interview transcript': 'बातचीत का रिकॉर्ड',
    'URGENT MEDICAL ATTENTION MAY BE REQUIRED': 'तुरंत डॉक्टरी मदद की ज़रूरत हो सकती है',
    'Please alert hospital staff immediately.': 'कृपया तुरंत अस्पताल स्टाफ़ को बताइये।',

    // ayush
    'Ayurveda intake · AYUSH format': 'आयुर्वेद इनटेक · आयुष प्रारूप',
    'Ayurvedic assessment (Ashtavidha / Dashavidha Pariksha)': 'आयुर्वेदिक आकलन (अष्टविध / दशविध परीक्षा)',
    'Ayurvedic assessment (AYUSH format)': 'आयुर्वेदिक आकलन (आयुष प्रारूप)',
    'Ayurvedic assessment (AYUSH format, patient reported)': 'आयुर्वेदिक आकलन (आयुष प्रारूप, मरीज़ द्वारा बताया गया)',
    'Save and continue to documents': 'सहेजकर दस्तावेज़ों पर जाइये',
    'Skip this format': 'यह प्रारूप छोड़िये',

    // documents
    'Your previous medical documents': 'आपके पुराने मेडिकल दस्तावेज़',
    'Drop files here, or tap to choose': 'फ़ाइल यहाँ छोड़िये, या चुनने के लिए दबाइये',
    'Structured extraction': 'संरचित जानकारी',
    'Text read from the file': 'फ़ाइल से पढ़ा गया पाठ',
    'Remove': 'हटाइये',
    'Choose hospital and specialist': 'अस्पताल और विशेषज्ञ चुनिये',
    'You choose where it goes': 'जानकारी कहाँ जाए, यह आप तय कीजिये',
    'Send report securely': 'रिपोर्ट सुरक्षित भेजिये',
    'Continue to review': 'जाँच के लिए आगे बढ़िये',

    // review / done
    'Please check what will go to your doctor': 'देखिये कि डॉक्टर को क्या भेजा जाएगा',
    'Report findings': 'रिपोर्ट के नतीजे',
    'Findings from your documents': 'आपके दस्तावेज़ों से मिली जानकारी',
    'Triage suggestion': 'प्राथमिकता सुझाव',
    'Suggested areas to explore': 'डॉक्टर के लिए सुझाए गए बिंदु',
    'Send securely to the hospital': 'अस्पताल को सुरक्षित भेजिये',
    '← Back to documents': '← दस्तावेज़ों पर वापस',
    'Try again': 'फिर कोशिश कीजिये',
    'Your history has been sent': 'आपका इतिहास भेज दिया गया है',
    '🖶 Print my copy': '🖶 मेरी कॉपी प्रिंट कीजिये',
    '🖶 Print': '🖶 प्रिंट',
    'Start a new patient': 'नया मरीज़ शुरू कीजिये',
    'Close session': 'सेशन बंद कीजिये',

    // returning patient history
    'Welcome back': 'आपका फिर से स्वागत है',
    'Do you have any problem today?': 'क्या आज कोई तकलीफ़ है?',
    'Yes, I have a problem': 'हाँ, तकलीफ़ है',
    'No, I am only checking my records': 'नहीं, मैं सिर्फ़ अपना रिकॉर्ड देख रहा/रही हूँ',
    'Past visits': 'पुरानी विज़िट',
    'Which doctor you saw, on which date, and what they wrote for you.': 'आपने किस डॉक्टर को कब दिखाया और उन्होंने आपके लिए क्या लिखा।',
    'Date & time': 'दिनांक व समय', 'Doctor seen': 'जिस डॉक्टर को दिखाया', 'Hospital / clinic': 'अस्पताल / क्लिनिक',
    'Not assigned yet': 'अभी तय नहीं', "Doctor's impression": 'डॉक्टर की राय', 'Notes for you': 'आपके लिए नोट',
    '📨 This report was sent to': '📨 यह रिपोर्ट इन्हें भेजी गई', 'Doctor': 'डॉक्टर', 'Specialty': 'विशेषज्ञता',
    'OPD timing': 'ओपीडी समय', 'Sent on': 'भेजी गई', 'Status': 'स्थिति', 'Reception desk': 'रिसेप्शन काउंटर',
    'Next time you log in with your patient ID, this visit, the doctor’s name and their prescription will be waiting for you under “Past visits”.': 'अगली बार अपनी पेशेंट आईडी से लॉगिन करने पर यह विज़िट, डॉक्टर का नाम और उनका पर्चा “पुरानी विज़िट” में मिल जाएगा।',
    'Prescription': 'दवा पर्ची',
    'Advice / notes': 'सलाह / टिप्पणी',
    'AI knows this is a follow-up': 'एआई जानता है कि यह फ़ॉलो-अप है',

    // doctor console
    'Patient queue': 'मरीज़ों की सूची',
    'Token': 'टोकन',
    'Patient': 'मरीज़',
    'Chief complaint': 'मुख्य शिकायत',
    'Documents': 'दस्तावेज़',
    'Priority': 'प्राथमिकता',
    'Status': 'स्थिति',
    'Open': 'खोलिये',
    'Analytics': 'विश्लेषण',
    'Age distribution': 'उम्र के अनुसार',
    'Language used': 'इस्तेमाल की गई भाषा',
    'Intake quality': 'इनटेक गुणवत्ता',
    'Clinical assistant': 'क्लिनिकल सहायक',
    'Ask the AI about today\u2019s queue': 'आज की सूची के बारे में एआई से पूछिये',
    '✓ Verify and save': '✓ पुष्टि कर सहेजिये',
    'Reject the extraction': 'निकाली गई जानकारी अस्वीकार कीजिये',
    '← Back to queue': '← सूची पर वापस',
    '← Back to home': '← होम पर वापस',

    // settings panel
    'Display and accessibility': 'दिखावट और सुगमता',
    'Appearance': 'दिखावट',
    'Light mode': 'लाइट मोड',
    'Dark mode': 'डार्क मोड',
    'High contrast mode': 'हाई कंट्रास्ट मोड',
    'Text size': 'अक्षर का आकार',
    'Normal': 'सामान्य',
    'Large': 'बड़ा',
    'Extra large': 'बहुत बड़ा',
    'Language': 'भाषा',
    'Voice and sound': 'आवाज़ और ध्वनि',
    'Read questions aloud automatically': 'सवाल अपने आप पढ़कर सुनाइये',
    'Your choices are saved on this device only.': 'आपकी पसंद सिर्फ़ इसी डिवाइस पर सहेजी जाती है।',
  };

  // Core phrases for the other Indian languages. Anything not listed stays in
  // English, so nothing ever disappears from the screen.
  const core = {
    mr: {
      'AI clinical intake': 'एआय क्लिनिकल इनटेक', 'Open health portal': 'हेल्थ पोर्टल उघडा',
      'I am a patient': 'मी रुग्ण आहे', 'I am a doctor or hospital staff': 'मी डॉक्टर किंवा रुग्णालय कर्मचारी आहे',
      'Patient login': 'रुग्ण लॉगिन', 'Doctor login': 'डॉक्टर लॉगिन', 'Login': 'लॉगिन',
      'Continue': 'पुढे चला', 'Back': 'मागे', 'Home': 'मुख्यपृष्ठ', 'Send': 'पाठवा',
      'Yes': 'होय', 'No': 'नाही', 'Not sure': 'माहित नाही',
      'Tap the microphone to speak': 'बोलण्यासाठी माइक दाबा', 'Listening… speak now': 'ऐकत आहोत… आता बोला',
      'Repeat question': 'प्रश्न पुन्हा सांगा', 'Do you have any problem today?': 'आज काही त्रास आहे का?',
      'Yes, I have a problem': 'होय, त्रास आहे', 'Prescription': 'औषधपत्र', 'Past visits': 'मागील भेटी',
      'Welcome back': 'पुन्हा स्वागत आहे', 'Settings': 'सेटिंग', 'Light mode': 'लाइट मोड', 'Dark mode': 'डार्क मोड',
      'Text size': 'अक्षर आकार', 'Language': 'भाषा', 'Review': 'तपासणी', 'Consent': 'संमती', 'Identify': 'ओळख',
      'Medical documents': 'वैद्यकीय कागदपत्रे', 'Complete': 'पूर्ण',
      'URGENT MEDICAL ATTENTION MAY BE REQUIRED': 'तातडीने वैद्यकीय मदतीची गरज असू शकते',
    },
    bn: {
      'AI clinical intake': 'এ���ই ক্লিনিক্যাল ইনটেক', 'Open health portal': 'হেলথ পোর্টাল খুলুন',
      'I am a patient': 'আমি রোগী', 'I am a doctor or hospital staff': 'আমি ডাক্তার বা হাসপাতাল কর্মী',
      'Patient login': 'রোগী লগইন', 'Doctor login': 'ডাক্তার লগইন', 'Login': 'লগইন',
      'Continue': 'এগিয়ে যান', 'Back': 'পিছনে', 'Home': 'হোম', 'Send': 'পাঠান',
      'Yes': 'হ্যাঁ', 'No': 'না', 'Not sure': 'জানি না',
      'Tap the microphone to speak': 'বলতে মাইকে চাপ দিন', 'Listening… speak now': 'শুনছি… এখন বলুন',
      'Repeat question': 'প্রশ্নটি আবার বলুন', 'Do you have any problem today?': 'আজ কি কোনো সমস্যা আছে?',
      'Yes, I have a problem': 'হ্যাঁ, সমস্যা আছে', 'Prescription': 'প্রেসক্রিপশন', 'Past visits': 'আগের ভিজিট',
      'Welcome back': 'আবার স্বাগতম', 'Settings': 'সেটিংস', 'Light mode': 'লাইট মোড', 'Dark mode': 'ডার্ক মোড',
      'Text size': 'লেখার আকার', 'Language': 'ভাষা', 'Review': 'পর্যালোচনা', 'Consent': 'সম্মতি', 'Identify': 'পরিচয়',
      'Medical documents': 'মেডিকেল নথি', 'Complete': 'সম্পূর্ণ',
      'URGENT MEDICAL ATTENTION MAY BE REQUIRED': 'জরুরি চিকিৎসার প্রয়োজন হতে পারে',
    },
    ta: {
      'AI clinical intake': 'ஏஐ மருத்துவ பதிவு', 'Open health portal': 'சுகாதார போர்ட்டலைத் திறக்கவும்',
      'I am a patient': 'நான் நோயாளி', 'I am a doctor or hospital staff': 'நான் மருத்துவர் அல்லது மருத்துவமனை ஊழியர்',
      'Patient login': 'நோயாளி உள்நுழைவு', 'Doctor login': 'மருத்துவர் உள்நுழைவு', 'Login': 'உள்நுழை',
      'Continue': 'தொடரவும்', 'Back': 'பின்', 'Home': 'முகப்பு', 'Send': 'அனுப்பு',
      'Yes': 'ஆம்', 'No': 'இல்லை', 'Not sure': 'தெரியவில்லை',
      'Tap the microphone to speak': 'பேச மைக்கை அழுத்தவும்', 'Listening… speak now': 'கேட்கிறோம்… இப்போது பேசுங்கள்',
      'Repeat question': 'கேள்வியை மீண்டும் சொல்', 'Do you have any problem today?': 'இன்று ஏதேனும் பிரச்சினை உள்ளதா?',
      'Yes, I have a problem': 'ஆம், பிரச்சினை உள்ளது', 'Prescription': 'மருந்துச் சீட்டு', 'Past visits': 'முந்தைய வருகைகள்',
      'Welcome back': 'மீண்டும் வரவேற்கிறோம்', 'Settings': 'அமைப்புகள்', 'Light mode': 'ஒளி பயன்முறை', 'Dark mode': 'இருள் பயன்முறை',
      'Text size': 'எழுத்து அளவு', 'Language': 'மொழி', 'Review': 'சரிபார்ப்பு', 'Consent': 'ஒப்புதல்', 'Identify': 'அடையாளம்',
      'Medical documents': 'மருத்துவ ஆவணங்கள்', 'Complete': 'முடிந்தது',
      'URGENT MEDICAL ATTENTION MAY BE REQUIRED': 'உடனடி மருத்துவ உதவி தேவைப்படலாம்',
    },
    te: {
      'AI clinical intake': 'ఏఐ క్లినికల్ ఇన్‌టేక్', 'Open health portal': 'హెల్త్ పోర్టల్ తెరవండి',
      'I am a patient': 'నేను రోగిని', 'I am a doctor or hospital staff': 'నేను డాక్టర్ లేదా ఆసుపత్రి సిబ్బంది',
      'Patient login': 'రోగి లాగిన్', 'Doctor login': 'డాక్టర్ లాగిన్', 'Login': 'లాగిన్',
      'Continue': 'కొనసాగించండి', 'Back': 'వెనక్కి', 'Home': 'హోమ్', 'Send': 'పంపండి',
      'Yes': 'అవును', 'No': 'కాదు', 'Not sure': 'తెలియదు',
      'Tap the microphone to speak': 'మాట్లాడటానికి మైక్ నొక్కండి', 'Listening… speak now': 'వింటున్నాం… ఇప్పుడు మాట్లాడండి',
      'Repeat question': 'ప్రశ్న మళ్లీ చెప్పండి', 'Do you have any problem today?': 'ఈరోజు ఏదైనా సమస్య ఉందా?',
      'Yes, I have a problem': 'అవును, సమస్య ఉంది', 'Prescription': 'మందుల చీటీ', 'Past visits': 'గత సందర్శనలు',
      'Welcome back': 'మళ్లీ స్వాగతం', 'Settings': 'సెట్టింగ్‌లు', 'Light mode': 'లైట్ మోడ్', 'Dark mode': 'డార్క్ మోడ్',
      'Text size': 'అక్షర పరిమాణం', 'Language': 'భాష', 'Review': 'సమీక్ష', 'Consent': 'సమ్మతి', 'Identify': 'గుర్తింపు',
      'Medical documents': 'వైద్య పత్రాలు', 'Complete': 'పూర్తి',
      'URGENT MEDICAL ATTENTION MAY BE REQUIRED': 'తక్షణ వైద్య సహాయం అవసరం కావచ్చు',
    },
    kn: {
      'AI clinical intake': 'ಎಐ ಕ್ಲಿನಿಕಲ್ ಇನ್‌ಟೇಕ್', 'Open health portal': 'ಹೆಲ್ತ್ ಪೋರ್ಟಲ್ ತೆರೆಯಿರಿ',
      'I am a patient': 'ನಾನು ರೋಗಿ', 'I am a doctor or hospital staff': 'ನಾನು ವೈದ್ಯ ಅಥವಾ ಆಸ್ಪತ್ರೆ ಸಿಬ್ಬಂದಿ',
      'Patient login': 'ರೋಗಿ ಲಾಗಿನ್', 'Doctor login': 'ವೈದ್ಯ ಲಾಗಿನ್', 'Login': 'ಲಾಗಿನ್',
      'Continue': 'ಮುಂದುವರಿಸಿ', 'Back': 'ಹಿಂದೆ', 'Home': 'ಮುಖಪುಟ', 'Send': 'ಕಳುಹಿಸಿ',
      'Yes': 'ಹೌದು', 'No': 'ಇಲ್ಲ', 'Not sure': 'ಗೊತ್ತಿಲ್ಲ',
      'Tap the microphone to speak': 'ಮಾತನಾಡಲು ಮೈಕ್ ಒತ್ತಿ', 'Listening… speak now': 'ಕೇಳುತ್ತಿದ್ದೇವೆ… ಈಗ ಮಾತನಾಡಿ',
      'Repeat question': 'ಪ್ರಶ್ನೆ ಪುನಃ ಹೇಳಿ', 'Do you have any problem today?': 'ಇಂದು ಯಾವುದೇ ತೊಂದರೆ ಇದೆಯೇ?',
      'Yes, I have a problem': 'ಹೌದು, ತೊಂದರೆ ಇದೆ', 'Prescription': 'ಔಷಧ ಚೀಟಿ', 'Past visits': 'ಹಿಂದಿನ ಭೇಟಿಗಳು',
      'Welcome back': 'ಮತ್ತೆ ಸ್ವಾಗತ', 'Settings': 'ಸೆಟ್ಟಿಂಗ್‌ಗಳು', 'Light mode': 'ಲೈಟ್ ಮೋಡ್', 'Dark mode': 'ಡಾರ್ಕ್ ಮೋಡ್',
      'Text size': 'ಅಕ್ಷರ ಗಾತ್ರ', 'Language': 'ಭಾಷೆ', 'Review': 'ಪರಿಶೀಲನೆ', 'Consent': 'ಒಪ್ಪಿಗೆ', 'Identify': 'ಗುರುತು',
      'Medical documents': 'ವೈದ್ಯಕೀಯ ದಾಖಲೆಗಳು', 'Complete': 'ಪೂರ್ಣ',
      'URGENT MEDICAL ATTENTION MAY BE REQUIRED': 'ತಕ್ಷಣದ ವೈದ್ಯಕೀಯ ನೆರವು ಬೇಕಾಗಬಹುದು',
    },
    gu: {
      'AI clinical intake': 'એઆઈ ક્લિનિકલ ઇનટેક', 'Open health portal': 'હેલ્થ પોર્ટલ ખોલો',
      'I am a patient': 'હું દર્દી છું', 'I am a doctor or hospital staff': 'હું ડૉક્ટર કે હોસ્પિટલ સ્ટાફ છું',
      'Patient login': 'દર્દી લોગિન', 'Doctor login': 'ડૉક્ટર લોગિન', 'Login': 'લોગિન',
      'Continue': 'આગળ વધો', 'Back': 'પાછળ', 'Home': 'હોમ', 'Send': 'મોકલો',
      'Yes': 'હા', 'No': 'ના', 'Not sure': 'ખબર નથી',
      'Tap the microphone to speak': 'બોલવા માટે માઇક દબાવો', 'Listening… speak now': 'સાંભળી રહ્યા છીએ… હવે બોલો',
      'Repeat question': 'પ્રશ્ન ફરી કહો', 'Do you have any problem today?': 'આજે કોઈ તકલીફ છે?',
      'Yes, I have a problem': 'હા, તકલીફ છે', 'Prescription': 'દવાની ચિઠ્ઠી', 'Past visits': 'અગાઉની મુલાકાતો',
      'Welcome back': 'ફરી સ્વાગત છે', 'Settings': 'સેટિંગ', 'Light mode': 'લાઇટ મોડ', 'Dark mode': 'ડાર્ક મોડ',
      'Text size': 'અક્ષર માપ', 'Language': 'ભાષા', 'Review': 'ચકાસણી', 'Consent': 'સંમતિ', 'Identify': 'ઓળખ',
      'Medical documents': 'મેડિકલ દસ્તાવેજો', 'Complete': 'પૂર્ણ',
      'URGENT MEDICAL ATTENTION MAY BE REQUIRED': 'તાત્કાલિક તબીબી મદદની જરૂર પડી શકે છે',
    },
  };

  const DICT = Object.assign({hi}, core);

  // Elements whose text must never be translated (patient words, IDs, data).
  const SKIP = 'script,style,code,textarea,input,.mono,.talk,[data-no-translate]';

  function lookup(map, text) {
    const trimmed = text.trim();
    if (!trimmed) return null;
    if (map[trimmed]) return text.replace(trimmed, map[trimmed]);
    return null;
  }

  function applyLang(root, lang) {
    const map = DICT[lang];
    const host = root || document.body;
    if (!map) return;
    const walker = document.createTreeWalker(host, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
        if (node.parentElement && node.parentElement.closest(SKIP)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      },
    });
    const jobs = [];
    let node;
    while ((node = walker.nextNode())) {
      const out = lookup(map, node.nodeValue);
      if (out) jobs.push([node, out]);
    }
    jobs.forEach(([n, v]) => { n.nodeValue = v });

    host.querySelectorAll('[placeholder]').forEach(el => {
      if (!el.dataset.ph) el.dataset.ph = el.getAttribute('placeholder');
      const out = lookup(map, el.dataset.ph);
      if (out) el.setAttribute('placeholder', out);
    });
    host.querySelectorAll('[aria-label]').forEach(el => {
      if (!el.dataset.al) el.dataset.al = el.getAttribute('aria-label');
      const out = lookup(map, el.dataset.al);
      if (out) el.setAttribute('aria-label', out);
    });
    host.querySelectorAll('option').forEach(el => {
      const out = lookup(map, el.textContent);
      if (out) el.textContent = out;
    });
  }

  window.MK = window.MK || {};
  window.MK.DICT = DICT;
  window.MK.applyLang = applyLang;
})();
