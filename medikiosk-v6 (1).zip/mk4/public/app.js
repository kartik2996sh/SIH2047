/*
 * MediKiosk 3 front end.
 *
 * One page, two access modes: patient kiosk and doctor / hospital console.
 * There is no scripted interview here. Every question, every judgement about
 * an answer, every report reading and the whole summary come from the server's
 * AI brain. The browser only shows what the AI decides.
 */
const API = location.protocol === 'file:' ? 'http://localhost:8787' : '';
const app = document.getElementById('app');
const statusPill = document.getElementById('status');

const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
const t = key => MK.t(S.lang, key);

/* ---------------- state ---------------- */
const S = {
  view: 'gate',            // gate | patientAccess | intake | doctorAccess | doctor
  lang: 'en',
  ai: {enabled: false},
  serverUp: false,
  // patient session
  step: 'identify',        // identify | consent | interview | documents | review | done
  patient: {},
  patientId: '',
  patientMode: '',
  directory: {hospitals: [], doctors: []},
  routing: {hospital: 'Suyash Hospital', specialty: '', doctorId: ''},
  consent: {},
  transcript: [],          // [{who, text}] for the chat bubbles
  history: [],             // [{question, answer}] sent to the AI
  record: {},              // structured record the AI keeps updating
  question: '',
  questionEn: '',
  chips: [],
  section: '',
  progress: 0,
  empathy: '',
  clarifyCount: 0,
  notes: [],
  urgent: [],
  reports: [],
  reading: false,
  readError: '',
  thinking: false,
  turnError: '',
  summary: null,
  summaryError: '',
  summarising: false,
  patientNote: '',
  submitted: null,
  ayush: {},              // Ayurveda (AYUSH) assessment filled after the voice interview
  visits: [],             // previous visits of a returning patient (with doctor notes / prescriptions)
  historyAsk: '',         // answer to "do you have any problem today?"
  // doctor session
  doc: {tab: 'queue', records: [], loading: false, error: '', open: null, search: '', ask: '', answer: null, asking: false, current: null},
};

/* ---------------- api ---------------- */
async function api(path, options = {}) {
  const res = await fetch(API + path, options);
  const text = await res.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {} } catch { data = {error: text.slice(0, 300)} }
  if (!res.ok) { const err = new Error(data.error || `Request failed (${res.status}).`); err.data = data; throw err }
  return data;
}

async function checkHealth() {
  try {
    const h = await api('/api/health');
    S.serverUp = true;
    S.ai = h.ai || {enabled: false};
    statusPill.className = S.ai.enabled ? 'pill live' : 'pill wait';
    statusPill.innerHTML = S.ai.enabled
      ? `<span class="dot"></span>AI brain on · ${esc(S.ai.provider)}`
      : '<span class="dot"></span>AI brain not connected';
  } catch {
    S.serverUp = false;
    statusPill.className = 'pill off';
    statusPill.innerHTML = '<span class="dot"></span>Server offline';
  }
}

/* ---------------- speech ---------------- */
let recog = null, listening = false;
function speech() {
  const Ctor = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Ctor) return null;
  if (recog) return recog;
  recog = new Ctor();
  recog.continuous = false;
  recog.interimResults = true;
  recog.onstart = () => { listening = true; micUi(); };
  recog.onerror = e => {
    listening = false; micUi();
    const map = {
      'not-allowed': 'Microphone permission was blocked. Allow it from the padlock icon in the address bar.',
      'service-not-allowed': 'Microphone permission was blocked by the browser settings.',
      'no-speech': 'Nothing was heard. Please tap the microphone and speak again.',
      'audio-capture': 'No microphone was found on this computer.',
      network: 'Speech recognition needs an internet connection in this browser.',
    };
    micState(map[e.error] || `Microphone error: ${e.error}`);
  };
  recog.onend = () => { listening = false; micUi(); };
  recog.onresult = e => {
    let text = '';
    for (const r of e.results) text += r[0].transcript;
    const box = document.getElementById('answer');
    if (box) box.value = text.trim();
    if (e.results[e.results.length - 1].isFinal) setTimeout(() => submitAnswer(), 350);
  };
  return recog;
}
function micUi() {
  const mic = document.getElementById('mic');
  if (mic) mic.classList.toggle('live', listening);
  micState(listening ? t('listening') : t('speak'));
}
function micState(message) {
  const el = document.getElementById('micstate');
  if (el) el.textContent = message;
}
function toggleMic() {
  const r = speech();
  if (!r) return micState('This browser cannot listen. Use Chrome or Edge, or type your answer below.');
  if (listening) return r.stop();
  r.lang = MK.locale(S.lang);
  try { r.start() } catch { /* already starting */ }
}
function speak(text) {
  if (!text || !window.speechSynthesis) return;
  try {
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = MK.locale(S.lang);
    u.rate = 0.95;
    speechSynthesis.speak(u);
  } catch {}
}

/* ---------------- shell ---------------- */
let translating = false;
function retranslate() {
  if (!window.MK || !MK.applyLang || translating) return;
  translating = true;
  try { MK.applyLang(document.body, S.lang) } finally { translating = false }
}

function render() {
  const map = {gate: viewGate, patientAccess: viewPatientAccess, intake: viewIntake, doctorAccess: viewDoctorAccess, doctor: viewDoctor};
  (map[S.view] || viewGate)();
  retranslate();
}

function aiBanner() {
  if (S.ai.enabled) return '';
  return `<div class="alert warn rise"><span>⚠</span><span>
    <b>The AI service is not switched on yet</b>
    MediKiosk has no scripted questions — the interview, the report reading and the summary all come from the AI.
    Hospital staff: put the key in <span class="mono">server/ai-key.mjs</span> and restart the server.
  </span></div>`;
}

/* ---------------- 1. role gate ---------------- */
function viewGate() {
  app.className = 'wrap homewrap';
  app.innerHTML = `
  <section class="homehero rise">
    <div class="homecopy">
      <span class="eyebrow">Connected care · one secure health journey</span>
      <h1>Smarter intake.<br><span class="hero-accent">More time for care.</span></h1>
      <p class="lead">Register once, keep your reports, talk to the same AI intake, and securely reach the right hospital specialist.</p>
      <div class="row"><button class="btn primary" id="startPortal">Open health portal</button><button class="btn ghost" id="seeHow">See how it works ↓</button></div>
      <div class="trustrow"><span>24/7 AI intake</span><span>Verified doctors</span><span>Reports stay linked</span><span>Physician reviewed</span></div>
    </div>
  </section>

  ${aiBanner()}

  <section class="portal-section" id="portal">
    <div class="sectionhead"><span class="eyebrow">Choose your portal</span><h2>Continue as patient or doctor</h2><p>New users can register. Existing users continue with their MediKiosk ID.</p></div>
    <div class="gate premium-gate">
      <button class="role rise" id="asPatient"><span class="ico">♥</span><h3>Patient login</h3><p class="tiny">New patient registration or returning patient login with saved history and reports.</p><span class="go">Enter patient portal →</span></button>
      <button class="role rise" id="asDoctor"><span class="ico">⚕</span><h3>Doctor login</h3><p class="tiny">Register your professional profile or access the assigned patient queue.</p><span class="go">Enter doctor portal →</span></button>
    </div>
  </section>

  <section class="deep-section alt" id="how"><div class="sectionhead"><span class="eyebrow">Simple and connected</span><h2>From health concern to the right doctor</h2></div>
    <div class="journey">${[['01','Identify','Register once or enter your patient ID.'],['02','Talk to AI','The existing AI gathers a safe clinical history.'],['03','Add reports','New and previous documents stay linked to you.'],['04','Route securely','Choose hospital, specialty and a matching doctor.']].map(x=>`<article><b>${x[0]}</b><h3>${x[1]}</h3><p>${x[2]}</p></article>`).join('')}</div>
  </section>

  <section class="deep-section"><div class="sectionhead"><span class="eyebrow">Care network</span><h2>Specialists, organised by expertise</h2><p>General surgery, physicians, neurosurgery and neuro medicine at Suyash Hospital.</p></div>
    <div class="specialty-grid">${[['🫀','General & laparoscopic surgery'],['🩺','General physician'],['🧠','Neurosurgeon'],['⚕','Neuro physician']].map(x=>`<div class="specialty"><span>${x[0]}</span><h3>${x[1]}</h3><p class="tiny">View matching doctors after your report is ready.</p></div>`).join('')}</div>
  </section>

  <section class="numbers"><div><b>15</b><span>Preloaded specialists</span></div><div><b>8</b><span>Supported languages</span></div><div><b>100%</b><span>Physician verification</span></div></section>

  <section class="deep-section alt"><div class="sectionhead"><span class="eyebrow">Designed for continuity</span><h2>Returning patients do not start from zero</h2></div>
    <div class="continuity"><div class="continuity-card"><span>📁</span><h3>Your documents stay with your ID</h3><p>Previous reports are restored at login and included as context for the AI intake.</p></div><div class="continuity-card"><span>🧠</span><h3>AI knows this is a follow-up</h3><p>The current AI integration remains unchanged, while returning-patient context is passed into the same safe workflow.</p></div><div class="continuity-card"><span>🔒</span><h3>You choose where it goes</h3><p>Filter by hospital, specialty and doctor before sending.</p></div></div>
  </section>

  <section class="finalcta"><span class="eyebrow">Ready when you are</span><h2>Start your connected care journey</h2><p>One identity. Complete history. The right clinician.</p><button class="btn primary" id="bottomStart">Choose portal</button></section>

  <details class="setwrap" id="setwrap" ${S.openSettings ? 'open' : ''}><summary>⚙ Settings · appearance, text size and language</summary><div id="settingsHost">${settingsPanel()}</div></details>`;
  const portal = () => document.getElementById('portal')?.scrollIntoView({behavior:'smooth'});
  on('startPortal', portal); on('bottomStart', portal); on('seeHow', () => document.getElementById('how')?.scrollIntoView({behavior:'smooth'}));
  on('asPatient', () => { S.view='patientAccess'; render() });
  on('asDoctor', () => { S.view='doctorAccess'; render() });
  wireSettings(); wireSettingsShortcut();
}

async function loadDirectory(){
  try { S.directory = await api('/api/directory') } catch { S.directory = {hospitals:['Suyash Hospital'], doctors:[]} }
}

function accessChoice(title, subtitle, existingLabel, newLabel){
  return `<div class="access-shell rise"><div class="access-head"><span class="eyebrow">Secure access</span><h1>${title}</h1><p>${subtitle}</p></div><div class="gate"><button class="role" id="existingAccess"><span class="ico">↩</span><h3>${existingLabel}</h3><p class="tiny">Use your MediKiosk ID to restore your profile.</p><span class="go">Login with ID →</span></button><button class="role" id="newAccess"><span class="ico">＋</span><h3>${newLabel}</h3><p class="tiny">Create a secure profile and receive your unique ID.</p><span class="go">Register now →</span></button></div><button class="btn ghost" id="toGate">← Back to home</button></div>`;
}

function viewPatientAccess(){
  window.scrollTo(0,0); requestAnimationFrame(()=>window.scrollTo(0,0)); setTimeout(()=>window.scrollTo(0,0),180);
  app.className='wrap';
  app.innerHTML=accessChoice('Patient access','Your reports and visit history stay connected to your patient ID.','Existing patient','New patient');
  on('toGate',()=>{S.view='gate';render()});
  on('newAccess',async()=>{S.patientMode='new';S.patient={returningPatient:false};S.patientId='';S.reports=[];S.record={};await loadDirectory();S.view='intake';S.step='identify';render()});
  on('existingAccess',()=>{
    app.innerHTML=`<div class="card rise auth-card"><span class="eyebrow">Returning patient</span><h2>Welcome back</h2><p class="tiny">Enter your patient ID. Saved reports and continuity context will be restored.</p><label class="field"><span>Patient ID</span><input id="patientLoginId" placeholder="e.g. MK-AB12CD" autocomplete="off" /></label><p class="err" id="patientLoginErr"></p><div class="row"><button class="btn primary" id="patientLoginGo">Restore my profile</button><button class="btn ghost" id="backAccess">Back</button></div></div>`;
    const go=async()=>{try{const out=await api('/api/patient/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({patientId:document.getElementById('patientLoginId').value})});S.patientMode='existing';S.patientId=out.patientId;S.patient={...out.patient,returningPatient:true,patientId:out.patientId,previousVisitCount:out.visitCount,previousSummary:out.previousSummary||''};S.reports=out.reports||[];S.record=out.lastRecord||{};S.visits=out.visits||[];S.historyAsk='';S.ayush=out.lastAyush||{};await loadDirectory();S.view='intake';S.step='history';render()}catch(e){document.getElementById('patientLoginErr').textContent=e.message}};
    on('patientLoginGo',go);on('backAccess',()=>{S.view='patientAccess';render()});document.getElementById('patientLoginId').onkeydown=e=>{if(e.key==='Enter')go()};
  });
}

function viewDoctorAccess(){
  window.scrollTo(0,0); requestAnimationFrame(()=>window.scrollTo(0,0)); setTimeout(()=>window.scrollTo(0,0),180);
  app.className='wrap';app.innerHTML=accessChoice('Doctor access','Create a professional profile or continue with your doctor ID.','Existing doctor','New doctor');
  on('toGate',()=>{S.view='gate';render()});
  on('existingAccess',()=>{app.innerHTML=`<div class="card rise auth-card"><span class="eyebrow">Doctor login</span><h2>Open your clinical console</h2><label class="field"><span>Doctor ID</span><input id="doctorLoginId" placeholder="e.g. DOC-SUY-001" /></label><p class="err" id="doctorLoginErr"></p><div class="row"><button class="btn primary" id="doctorLoginGo">Login</button><button class="btn ghost" id="backAccess">Back</button></div></div>`;const go=async()=>{try{const out=await api('/api/doctor/profile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({doctorId:document.getElementById('doctorLoginId').value})});S.doc.current=out.doctor;S.view='doctor';renderDoctor()}catch(e){document.getElementById('doctorLoginErr').textContent=e.message}};on('doctorLoginGo',go);on('backAccess',()=>{S.view='doctorAccess';render()})});
  on('newAccess',()=>{app.innerHTML=`<div class="card rise"><span class="eyebrow">Doctor registration</span><h2>Create your professional profile</h2><div class="grid g2"><label class="field"><span>Full name</span><input id="d-name" /></label><label class="field"><span>Mobile number</span><input id="d-phone" inputmode="numeric" /></label><label class="field"><span>Qualification</span><input id="d-qualification" placeholder="MBBS, MD, MS…" /></label><label class="field"><span>Medical specialization</span><input id="d-specialty" placeholder="Cardiology, General Medicine…" /></label><label class="field"><span>Practice type</span><select id="d-practice"><option>Hospital</option><option>Self clinic</option></select></label><label class="field"><span>Hospital / clinic name</span><input id="d-hospital" /></label><label class="field"><span>OPD timings</span><input id="d-opd" placeholder="Mon–Sat, 10:00 AM–2:00 PM" /></label><label class="field"><span>Experience</span><input id="d-exp" placeholder="e.g. 12 years" /></label><label class="field"><span>Registration number</span><input id="d-reg" /></label><label class="field"><span>Consultation mode</span><select id="d-mode"><option>In person</option><option>Video and in person</option><option>Video</option></select></label></div><p class="err" id="doctorRegErr"></p><div class="row"><button class="btn primary" id="doctorRegGo">Register doctor</button><button class="btn ghost" id="backAccess">Back</button></div></div>`;on('backAccess',()=>{S.view='doctorAccess';render()});on('doctorRegGo',async()=>{const v=id=>document.getElementById(id).value.trim();try{const out=await api('/api/doctor/register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:v('d-name'),phone:v('d-phone'),qualification:v('d-qualification'),specialty:v('d-specialty'),practiceType:v('d-practice'),hospital:v('d-hospital'),opd:v('d-opd'),experience:v('d-exp'),registrationNumber:v('d-reg'),consultationMode:v('d-mode')})});S.doc.current=out.doctor;alert(`Registration complete. Your doctor ID is ${out.doctor.doctorId}. Please save it.`);S.view='doctor';renderDoctor()}catch(e){document.getElementById('doctorRegErr').textContent=e.message}})});
}

/* ---------------- 2. patient kiosk ---------------- */
/* The journey is built for the person in front of the kiosk: a returning
   patient first sees their own medical history, and everybody gets the
   Ayurveda (AYUSH) profile right after the spoken interview. */
function steps() {
  const list = [['identify', 'Identify']];
  if (S.patientMode === 'existing') list.push(['history', 'Your history']);
  list.push(['consent', 'Consent'], ['interview', 'Conversation'], ['ayush', 'Ayurveda profile'],
    ['documents', 'Documents'], ['review', 'Review'], ['done', 'Complete']);
  return list;
}

function stepBar() {
  const STEPS = steps();
  const index = Math.max(0, STEPS.findIndex(s => s[0] === S.step));
  const pct = S.step === 'interview' && S.progress
    ? ((index + (S.progress / 100)) / STEPS.length) * 100
    : ((index + 1) / STEPS.length) * 100;
  return `<div class="prog">
    <span class="stagechip">${index + 1} / ${STEPS.length} · ${STEPS[index][1]}</span>
    <span class="bar"><i style="width:${Math.min(100, Math.round(pct))}%"></i></span>
    ${S.section ? `<span class="tiny">${esc(S.section)}</span>` : ''}
  </div>`;
}

function urgentBanner() {
  if (!S.urgent.length) return '';
  return `<div class="siren">
    <h3 style="color:var(--bad)">URGENT MEDICAL ATTENTION MAY BE REQUIRED</h3>
    <p><b>Please alert hospital staff immediately.</b></p>
    <ul>${S.urgent.map(r => `<li>${esc(r)}</li>`).join('')}</ul>
  </div>`;
}

function viewIntake() {
  const body = {
    identify: stepIdentify, history: stepHistory, consent: stepConsent, interview: stepInterview,
    ayush: stepAyush, documents: stepDocuments, review: stepReview, done: stepDone,
  }[S.step] || stepIdentify;
  app.innerHTML = `${stepBar()}${urgentBanner()}${aiBanner()}<div id="stepBody"></div>`;
  document.getElementById('stepBody').innerHTML = body();
  wireStep();
}

/* --- 2a. identify --- */
function stepIdentify() {
  const p = S.patient;
  const problems = S.idProblems || [];
  const bad = f => problems.some(x => x.field === f) ? 'field bad' : 'field';
  const msg = f => {
    const found = problems.find(x => x.field === f);
    return found ? `<span class="err">${esc(found.message)}</span>` : '';
  };
  return `<div class="card rise">
    <span class="eyebrow">Step 1</span>
    <h2>Who is visiting today?</h2>
    <p class="tiny">The AI checks these details for you. A fake name, an impossible age or an invalid Aadhaar or ABHA number will not be accepted.</p>
    <hr class="sep" />
    <div class="grid g2">
      <label class="${bad('name')}"><span>Full name</span><input id="f-name" value="${esc(p.name || '')}" placeholder="As written on your ID" />${msg('name')}</label>
      <label class="${bad('age')}"><span>Age in years</span><input id="f-age" type="number" min="0" max="120" value="${esc(p.age || '')}" />${msg('age')}</label>
      <label class="${bad('gender')}"><span>Gender</span><select id="f-gender">
        ${['', 'Female', 'Male', 'Other', 'Prefer not to say'].map(g => `<option value="${g}" ${p.gender === g ? 'selected' : ''}>${g || 'Select…'}</option>`).join('')}
      </select>${msg('gender')}</label>
      <label class="${bad('phone')}"><span>Mobile number</span><input id="f-phone" inputmode="numeric" value="${esc(p.phone || '')}" placeholder="10 digits" />${msg('phone')}</label>
      <label class="field"><span>ID type</span><select id="f-type">
        ${[['none', 'No ID today'], ['abha', 'ABHA number (14 digits)'], ['aadhaar', 'Aadhaar number (12 digits)']]
          .map(([v, l]) => `<option value="${v}" ${(p.idType || 'none') === v ? 'selected' : ''}>${l}</option>`).join('')}
      </select></label>
      <label class="${bad('id')}"><span>ID number</span><input id="f-id" inputmode="numeric" value="${esc(p.idNumber || '')}" placeholder="Leave blank if no ID" />${msg('id')}</label>
    </div>
    ${S.idMessage ? `<div class="alert bad"><span>⚠</span><span>${esc(S.idMessage)}</span></div>` : ''}
    <div class="row" style="margin-top:16px">
      <button class="btn primary" id="idNext" ${S.checkingId ? 'disabled' : ''}>${S.checkingId ? 'Checking details…' : 'Continue'}</button>
      <button class="btn ghost" id="toGate">Back</button>
    </div>
  </div>`;
}

async function submitIdentity() {
  const val = id => document.getElementById(id)?.value?.trim() || '';
  S.patient = {
    name: val('f-name'), age: val('f-age'), gender: val('f-gender'),
    phone: val('f-phone'), idType: val('f-type'), idNumber: val('f-id'),
  };
  S.idProblems = []; S.idMessage = ''; S.checkingId = true; viewIntake();
  try {
    const out = await api('/api/identity/check', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({form: S.patient, language: S.lang}),
    });
    S.checkingId = false;
    if (!out.ok) {
      S.idProblems = out.problems || [];
      S.idMessage = out.messageForPatient || 'Please correct the highlighted details.';
      return viewIntake();
    }
    if (S.patientMode === 'new' && !S.patientId) {
      const reg = await api('/api/patient/register', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({patient:S.patient})});
      S.patientId = reg.patientId; S.patient.patientId = reg.patientId;
    }
    S.step = 'consent';
    viewIntake();
  } catch (err) {
    S.checkingId = false;
    S.idMessage = err.message;
    viewIntake();
  }
}

/* --- 1b. returning patient: full medical history, then the AI asks whether
   there is a problem today. Consent is asked again only after a "yes", so it
   matches the situation of this visit. --- */
function stepHistory() {
  const p = S.patient;
  const visits = S.visits || [];
  const rx = visits.filter(v => v.prescription || v.doctorNotes || v.diagnosis);
  const line = (label, value) => `<div class="kv"><span>${label}</span><b>${esc(value || '—')}</b></div>`;
  return `<div class="card rise">
    <span class="eyebrow">Welcome back \u00b7 ${esc(S.patientId)}</span>
    <h2>${esc(p.name || 'Your')} medical history at this hospital</h2>
    <p class="lead">This is everything already saved with your patient ID. Nothing is being asked again.</p>
    <div class="grid g3">${line('Age', p.age)}${line('Gender', p.gender)}${line('Mobile', p.phone)}
      ${line('Previous visits', String(visits.length))}${line('Documents on file', String((S.reports || []).length))}
      ${line('Last visit', visits[0] ? new Date(visits[0].submittedAt).toLocaleDateString() : 'First visit')}</div>

    <hr class="sep" />
    <h3>Doctor\u2019s prescriptions and notes for you</h3>
    ${rx.length ? rx.map(v => `<div class="rxbox">
        <div class="row" style="justify-content:space-between">
          <b>${esc(new Date(v.submittedAt).toLocaleDateString())} \u00b7 ${esc(v.doctorName || v.token || '')}</b>
          <span class="tag ${/Reviewed/.test(v.status || '') ? 'ok' : 'grey'}">${esc(v.status || '')}</span>
        </div>
        ${v.diagnosis ? `<p><b>Impression:</b> ${esc(v.diagnosis)}</p>` : ''}
        ${v.prescription ? `<div class="block"><h4>Prescription</h4><pre class="rx">${esc(v.prescription)}</pre></div>` : ''}
        ${v.doctorNotes ? `<div class="block"><h4>Advice / notes</h4><p>${esc(v.doctorNotes)}</p></div>` : ''}
      </div>`).join('')
      : '<p class="tiny">Your doctor has not written a prescription or note yet. It will appear here as soon as it is saved.</p>'}

    ${visits.length ? `<hr class="sep" /><h3>Past visits</h3>
      <p class="tiny">Which doctor you saw, on which date, and what they wrote for you.</p>
      <table class="mono"><thead><tr><th>Date &amp; time</th><th>Token</th><th>Doctor seen</th><th>Hospital / clinic</th><th>Main concern</th><th>Documents</th><th>Status</th></tr></thead>
      <tbody>${visits.map(v => `<tr><td>${esc(new Date(v.submittedAt).toLocaleString())}</td><td>${esc(v.token || '')}</td>
        <td>${esc(v.doctorName || 'Not assigned yet')}</td><td>${esc(v.hospital || '—')}</td>
        <td>${esc(v.chiefComplaint || '—')}</td><td>${esc(String(v.reportCount || 0))}</td><td>${esc(v.status || '')}</td></tr>`).join('')}</tbody></table>
      ${visits.filter(v => v.diagnosis || v.doctorNotes || v.prescription).map(v => `<div class="block"><h4>Visit ${esc(v.token || '')} · ${esc(new Date(v.submittedAt).toLocaleDateString())} · ${esc(v.doctorName || 'Doctor')}${v.hospital ? ' · ' + esc(v.hospital) : ''}</h4>
        ${v.diagnosis ? `<p><b>Doctor's impression:</b> ${esc(v.diagnosis)}</p>` : ''}
        ${v.doctorNotes ? `<p><b>Notes for you:</b> ${esc(v.doctorNotes)}</p>` : ''}
        ${v.prescription ? `<div class="rxbox"><b>Prescription</b><pre class="rx">${esc(v.prescription)}</pre></div>` : ''}
        ${v.reviewedAt ? `<p class="tiny">Reviewed on ${esc(new Date(v.reviewedAt).toLocaleString())}</p>` : ''}</div>`).join('')}` : ''}

    ${(S.reports || []).length ? `<div class="alert info"><span>\ud83d\udcc1</span><span><b>${(S.reports || []).length} document(s) already on file</b>
      ${esc((S.reports || []).map(r => r.documentName).filter(Boolean).slice(0, 6).join(', '))} \u2014 these stay attached to you, you do not have to upload them again.</span></div>` : ''}

    <hr class="sep" />
    <div class="ask">
      <h2>Do you have any problem today?</h2>
      <p class="sub">If yes, the AI will continue from your history above. If not, you can close the session.</p>
      <div class="row" style="justify-content:center">
        <button class="btn primary" id="probYes">Yes, I have a problem</button>
        <button class="btn ghost" id="probNo">No, I am only checking my records</button>
      </div>
      <button class="btn quiet" id="readHistory" style="margin-top:14px">\ud83d\udd0a Read this aloud</button>
    </div>
    ${S.historyAsk === 'no' ? `<div class="alert good"><span>\u2713</span><span>Good to hear. Your records stay saved with ID <b>${esc(S.patientId)}</b>. Come back any time \u2014 nothing new will be sent to a doctor.</span></div>
      <button class="btn ghost" id="toGate">Close session</button>` : ''}
  </div>`;
}

/* --- 2c-2. Ayurveda (AYUSH) assessment, shown right after the voice
   interview. Values the AI already gathered are offered as context; the
   patient or the volunteer confirms them. --- */
const AYUSH_FIELDS = [
  ['prakriti', 'Prakriti (body constitution)', ['', 'Vata', 'Pitta', 'Kapha', 'Vata-Pitta', 'Pitta-Kapha', 'Vata-Kapha', 'Sama (balanced)', 'Not sure']],
  ['vikriti', 'Vikriti (present imbalance)', ['', 'Vata', 'Pitta', 'Kapha', 'Vata-Pitta', 'Pitta-Kapha', 'Vata-Kapha', 'Not sure']],
  ['sara', 'Sara (tissue quality)', ['', 'Pravara (excellent)', 'Madhyama (moderate)', 'Avara (low)', 'Not sure']],
  ['samhanana', 'Samhanana (body compactness)', ['', 'Susamhata (well built)', 'Madhyama (moderate)', 'Asamhata (loose)', 'Not sure']],
  ['pramana', 'Pramana (body proportion / build)', ['', 'Tall', 'Medium', 'Short', 'Not sure']],
  ['satmya', 'Satmya (suitability, habits that suit you)', ['', 'Sarvarasa (all tastes)', 'Vyayama (exercise)', 'Ekarasa (one taste only)', 'Not sure']],
  ['sattva', 'Sattva (mental strength)', ['', 'Pravara (strong)', 'Madhyama (moderate)', 'Avara (low)', 'Not sure']],
  ['aharaShakti', 'Ahara Shakti (appetite / digestion capacity)', ['', 'Good', 'Moderate', 'Poor', 'Variable']],
  ['vyayamaShakti', 'Vyayama Shakti (exercise tolerance)', ['', 'Good', 'Moderate', 'Poor']],
  ['vaya', 'Vaya (age stage)', ['', 'Bala (child)', 'Madhya (adult)', 'Vriddha (elderly)']],
  ['agni', 'Agni (digestive fire)', ['', 'Sama (balanced)', 'Vishama (irregular)', 'Tikshna (sharp)', 'Manda (slow)']],
  ['koshtha', 'Koshtha (bowel tendency)', ['', 'Mridu (soft / loose)', 'Madhyama (regular)', 'Krura (hard / constipated)']],
  ['nidra', 'Nidra (sleep)', ['', 'Sound', 'Disturbed', 'Excessive', 'Insomnia']],
  ['vihara', 'Vihara (daily routine / activity)', ['', 'Sedentary', 'Moderately active', 'Physically demanding', 'Night shift']],
];

function stepAyush() {
  const a = S.ayush || {};
  const hint = S.record?.ayush || '';
  const sel = (key, label, options) => `<label class="field"><span>${label}</span><select id="ay-${key}">
    ${options.map(o => `<option value="${esc(o)}" ${a[key] === o ? 'selected' : ''}>${o || 'Select\u2026'}</option>`).join('')}
  </select></label>`;
  return `<div class="card rise">
    <span class="eyebrow">Ayurveda intake \u00b7 AYUSH format</span>
    <h2>Ayurvedic assessment (Ashtavidha / Dashavidha Pariksha)</h2>
    <p class="lead">The spoken interview is complete. This AYUSH format is added for the Ayurveda physician \u2014 fill what you know, leave the rest.</p>
    ${hint ? `<div class="alert info"><span>\ud83e\udde0</span><span><b>From your conversation</b> ${esc(hint)}</span></div>` : ''}
    <div class="grid g3 ayushgrid">${AYUSH_FIELDS.map(f => sel(f[0], f[1], f[2])).join('')}</div>
    <label class="field"><span>Nidana / Hetu \u2014 what do you feel caused this problem?</span>
      <textarea id="ay-nidana" rows="2" placeholder="Food, season, travel, stress, sleep\u2026">${esc(a.nidana || '')}</textarea></label>
    <label class="field"><span>Ahara \u2014 usual diet</span>
      <textarea id="ay-ahara" rows="2" placeholder="Vegetarian, spicy, irregular meals, tea\u2026">${esc(a.ahara || '')}</textarea></label>
    <div class="alert warn"><span>\u26a0</span><span>This is a recorded observation only. Dosha assessment and treatment are decided by the physician.</span></div>
    <div class="row">
      <button class="btn primary" id="ayushNext">Save and continue to documents</button>
      <button class="btn ghost" id="ayushSkip">Skip this format</button>
      <button class="btn quiet" id="backToTalk">\u2190 Back to questions</button>
    </div>
  </div>`;
}

function collectAyush() {
  const out = {};
  AYUSH_FIELDS.forEach(f => { const v = document.getElementById('ay-' + f[0])?.value?.trim(); if (v) out[f[0]] = v });
  ['nidana', 'ahara'].forEach(k => { const v = document.getElementById('ay-' + k)?.value?.trim(); if (v) out[k] = v });
  S.ayush = out;
  const text = Object.entries(out).map(([k, v]) => {
    const found = AYUSH_FIELDS.find(f => f[0] === k);
    return `${found ? found[1] : k}: ${v}`;
  }).join('; ');
  S.notes = (S.notes || []).filter(n => !String(n).startsWith('AYUSH assessment:'));
  if (text) S.notes.push('AYUSH assessment: ' + text);
}

/* --- 2b. consent --- */
function stepConsent() {
  const c = S.consent;
  const line = (id, label, note) => `<label class="row" style="gap:10px;align-items:flex-start;margin-bottom:12px">
    <input type="checkbox" id="${id}" ${c[id] ? 'checked' : ''} style="margin-top:5px" />
    <span><b style="color:var(--ink)">${label}</b><br /><span class="tiny">${note}</span></span></label>`;
  return `<div class="card rise">
    <span class="eyebrow">Consent${S.patientMode === 'existing' ? ' for today’s visit' : ''}</span>
    <h2>Your consent, in plain words</h2>
    ${S.patientMode === 'existing' ? `<div class="alert info"><span>↩</span><span>You are a returning patient (<b>${esc(S.patientId)}</b>). Consent is taken again for this new problem, and your old reports stay attached.</span></div>` : ''}
    <p class="lead">You decide what MediKiosk may do. You can stop at any time and nothing will be sent.</p>
    <button class="btn ghost" id="readAloud">🔊 Read this aloud</button>
    <hr class="sep" />
    ${line('collect', 'Collect my medical history at this kiosk', 'Questions are asked by voice or touch and your answers are stored only for this visit.')}
    ${line('documents', 'Read the documents I upload', 'Old reports and prescriptions are scanned so the doctor can see them with your history.')}
    ${line('share', 'Share the prepared summary with my doctor', 'The doctor reviews and verifies everything before your consultation.')}
    ${line('ai', 'Let AI organise my information', 'AI writes a draft only. It never diagnoses and never prescribes.')}
    <div class="alert info"><span>🔒</span><span>Temporary session data is cleared after submission.</span></div>
    <div class="row">
      <button class="btn primary" id="consentNext">I agree, continue</button>
      <button class="btn ghost" id="consentBack">Back</button>
    </div>
  </div>`;
}

/* --- 2c. AI interview --- */
function stepInterview() {
  return `<div class="card rise">
    <span class="eyebrow">Step 3 · ${esc(S.section || 'Conversation')}</span>
    <h2>Tell me what is happening</h2>
    <p class="tiny">Nothing here is pre-written. The AI listens to each answer and decides what to ask next.</p>
    <div class="talk" id="talk">
      ${S.transcript.map(m => `<div class="msg ${m.who}"><span class="who">${m.who === 'me' ? 'You' : m.who === 'note' ? 'Please note' : 'MediKiosk AI'}</span>${esc(m.text)}</div>`).join('')}
      ${S.thinking ? '<div class="msg ai"><span class="who">MediKiosk AI</span><span class="dots"><i></i><i></i><i></i></span></div>' : ''}
    </div>
    ${S.turnError ? `<div class="alert bad"><span>⚠</span><span>${esc(S.turnError)}</span></div>` : ''}
    <div class="ask">
      <h2>${esc(S.question || (S.thinking ? 'Thinking…' : ''))}</h2>
      ${S.empathy ? `<p class="sub">${esc(S.empathy)}</p>` : ''}
      <button class="mic" id="mic" aria-label="Tap to speak">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">
          <path d="M12 3a3 3 0 0 1 3 3v6a3 3 0 0 1-6 0V6a3 3 0 0 1 3-3z" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3" />
        </svg>
      </button>
      <p class="tiny" id="micstate">${esc(t('speak'))}</p>
      <div class="answerbar">
        <input id="answer" placeholder="Your words appear here — you can also type" aria-label="Your answer" />
        <button class="btn primary" id="send">${esc(t('send'))}</button>
      </div>
      ${S.chips.length ? `<div class="chips">${S.chips.map(c => `<button data-chip="${esc(c)}">${esc(c)}</button>`).join('')}</div>` : ''}
      <div class="row" style="justify-content:center;margin-top:16px">
        <button class="btn ghost" id="repeat">🔊 ${esc(t('repeat'))}</button>
        <button class="btn quiet" id="skipToDocs">Skip to my reports →</button>
      </div>
    </div>
  </div>`;
}

async function nextTurn(answer) {
  S.thinking = true; S.turnError = ''; viewIntake();
  try {
    const out = await api('/api/interview/turn', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        patient: S.patient, transcript: S.history, reports: S.reports,
        record: S.record, language: S.lang, answer, clarifyCount: S.clarifyCount,
      }),
    });
    S.thinking = false;

    if (out.needsClarification) {
      // The answer was not usable, so it is removed from the record.
      S.clarifyCount += 1;
      if (S.history.length) S.history.pop();
      if (out.clarifyReason) S.transcript.push({who: 'note', text: out.clarifyReason});
    } else {
      S.clarifyCount = 0;
    }

    if (out.record && typeof out.record === 'object') {
      for (const [k, v] of Object.entries(out.record)) if (v) S.record[k] = v;
    }
    if (out.noteForDoctor) S.notes.push(out.noteForDoctor);
    (out.urgentReasons || []).forEach(r => { if (!S.urgent.includes(r)) S.urgent.push(r) });
    S.section = out.sectionLabel || S.section;
    S.progress = Number(out.progress) || S.progress;
    S.empathy = out.empathy || '';

    if (out.finished) {
      S.step = 'ayush';
      return viewIntake();
    }
    S.questionEn = out.question || '';
    S.question = (S.lang !== 'en' && out.translated) ? out.translated : out.question;
    S.chips = (out.chips || []).slice(0, 4);
    S.transcript.push({who: 'ai', text: S.question});
    viewIntake();
    speak(S.question);
  } catch (err) {
    S.thinking = false;
    S.turnError = err.message;
    viewIntake();
  }
}

function submitAnswer(forced) {
  const box = document.getElementById('answer');
  const answer = String(typeof forced === 'string' ? forced : (box?.value ?? '')).trim();
  if (!answer) return micState('Please speak or type an answer first.');
  if (listening) recog.stop();
  S.transcript.push({who: 'me', text: answer});
  S.history.push({question: S.questionEn || S.question, answer});
  if (box) box.value = '';
  nextTurn(answer);
}

/* --- 2d. documents --- */
function reportCard(r, i) {
  const engine = r.engine === 'ai'
    ? '<span class="tag plum">Read by AI · verify</span>'
    : '<span class="tag grey">OCR only · verify</span>';
  const cls = s => /Above/.test(s) ? 'high' : /Below/.test(s) ? 'low' : /Within/.test(s) ? 'ok' : 'grey';
  return `<div class="card tight rise" style="margin-bottom:16px">
    <div class="row" style="justify-content:space-between">
      <div><h3>${esc(r.documentName || 'Document')}</h3>
      <span class="tag low">${esc(r.documentType || 'Document')}</span>
      ${r.reportDate ? `<span class="tag grey">${esc(r.reportDate)}</span>` : ''}
      ${r.labName ? `<span class="tag grey">${esc(r.labName)}</span>` : ''}</div>
      <div class="row">${engine}<button class="btn danger" data-drop="${i}">Remove</button></div>
    </div>
    ${(r.labValues || []).length ? `<table><thead><tr><th>Test</th><th>Value</th><th>Usual range</th><th>Comparison</th></tr></thead>
      <tbody>${r.labValues.map(v => `<tr><td><b style="color:var(--ink)">${esc(v.name)}</b></td>
        <td>${esc(v.value)} ${esc(v.unit || '')}</td><td>${esc(v.reference || '—')}</td>
        <td><span class="tag ${cls(v.status)}">${esc(v.status || 'Not compared')}</span></td></tr>`).join('')}</tbody></table>` : ''}
    ${(r.testResults || []).length ? `<div class="row" style="margin-top:10px">${r.testResults.map(x =>
      `<span class="tag ${/Positive|Reactive/i.test(x.result) ? 'pos' : 'ok'}">${esc(x.name)}: ${esc(x.result)}</span>`).join('')}</div>` : ''}
    ${(r.medicines || []).length ? `<p class="tiny"><b>Medicines printed on this document:</b> ${r.medicines.map(m =>
      esc([m.name, m.dose, m.frequency, m.duration].filter(Boolean).join(' '))).join(' · ')}</p>` : ''}
    ${r.patientExplanation ? `<div class="alert info"><span>🧠</span><span>${esc(r.patientExplanation)}</span></div>` : ''}
    ${(r.doctorHighlights || []).length ? `<div class="alert warn"><span>⚑</span><span><b>Important findings for doctor review</b>
      ${r.doctorHighlights.map(h => esc(h)).join('<br />')}</span></div>` : ''}
    ${r.rawText ? `<details class="raw"><summary>Show the exact text read from this file</summary><pre>${esc(r.rawText.slice(0, 4000))}</pre></details>` : ''}
    <p class="tiny">Outside the reference range values must be checked against the original report by a clinician.</p>
  </div>`;
}

function stepDocuments() {
  return `<div class="card rise">
    <span class="eyebrow">Step 4</span>
    <h2>Your previous medical documents</h2>
    <p class="lead">Lab reports, prescriptions, discharge summaries, X-ray reports — photograph or upload them and the AI will read them.</p>
    <div class="drop" id="drop">
      <div class="big">📄</div>
      <h3>Drop files here, or tap to choose</h3>
      <p class="tiny">PDF, JPG, PNG, WEBP or TIFF · up to 25 MB each</p>
      <input type="file" id="file" multiple accept=".pdf,.png,.jpg,.jpeg,.webp,.bmp,.tif,.tiff" style="display:none" />
      ${S.reading ? '<div class="scanner"><i></i></div><p class="tiny">Scanning and reading with AI…</p>' : ''}
    </div>
    ${S.readError ? `<div class="alert bad"><span>⚠</span><span>${esc(S.readError)}</span></div>` : ''}
    <div style="margin-top:18px">${S.reports.map(reportCard).join('') || '<p class="tiny">No documents added yet. You can skip this step.</p>'}</div>
    ${routingPanel()}
    <div class="row">
      <button class="btn primary" id="docsNext">Continue to review</button>
      <button class="btn ghost" id="backToTalk">← Back to questions</button>
    </div>
  </div>`;
}


function inferSpecialty(){
  const text=JSON.stringify({record:S.record,history:S.history,reports:S.reports}).toLowerCase();
  if(/brain|headache|seizure|stroke|nerve|neuro/.test(text)) return 'Neuro Physician';
  if(/surgery|hernia|gall|appendix|laparo/.test(text)) return 'General & Laparoscopic Surgeon';
  return 'General Physician';
}
function routingPanel(){
  const suggested=S.routing.specialty||inferSpecialty();
  const specialties=[...new Set((S.directory.doctors||[]).map(d=>d.specialty))].sort();
  const hospital=S.routing.hospital||'Suyash Hospital';
  const matches=(S.directory.doctors||[]).filter(d=>(!hospital||d.hospital===hospital)&&(!suggested||d.specialty===suggested));
  return `<div class="routebox"><div class="sectionhead left"><span class="eyebrow">Send report securely</span><h3>Choose hospital and specialist</h3><p class="tiny">Suggested from the current concern: <b>${esc(suggested)}</b>. You can change it.</p></div><div class="grid g3"><label class="field"><span>Hospital</span><select id="routeHospital">${(S.directory.hospitals||['Suyash Hospital']).map(h=>`<option ${h===hospital?'selected':''}>${esc(h)}</option>`).join('')}</select></label><label class="field"><span>Specialty</span><select id="routeSpecialty">${specialties.map(x=>`<option ${x===suggested?'selected':''}>${esc(x)}</option>`).join('')}</select></label><label class="field"><span>Doctor</span><select id="routeDoctor"><option value="">Select doctor</option>${matches.map(d=>`<option value="${esc(d.doctorId)}" ${d.doctorId===S.routing.doctorId?'selected':''}>${esc(d.name)} · ${esc(d.opd)}</option>`).join('')}</select></label></div></div>`;
}

async function handleFiles(files) {
  for (const file of files) {
    S.reading = true; S.readError = ''; viewIntake();
    try {
      const query = `?lang=${encodeURIComponent(S.lang)}&patient=${encodeURIComponent(JSON.stringify({age: S.patient.age, gender: S.patient.gender}))}`;
      const out = await api('/api/report/read' + query, {
        method: 'POST',
        headers: {'Content-Type': 'application/octet-stream', 'X-Filename': encodeURIComponent(file.name)},
        body: file,
      });
      S.reports.push({documentName: file.name, ...out});
      (out.followUpQuestions || []).forEach(q => S.notes.push(`From ${file.name}: ${q}`));
    } catch (err) { S.readError = err.message }
    S.reading = false; viewIntake();
  }
}

/* --- 2e. review --- */
function stepReview() {
  const s = S.summary;
  const sec = (label, value) => `<div class="block"><h4>${label}</h4><p>${esc(value || 'Not reported')}</p></div>`;
  return `<div class="card rise">
    <span class="eyebrow">Step 5</span>
    <h2>Please check what will go to your doctor</h2>
    ${S.summarising ? '<div class="skeleton"></div><div class="skeleton" style="width:80%"></div><div class="skeleton" style="width:60%"></div><p class="tiny">The AI is writing your clinical summary…</p>' : ''}
    ${S.summaryError ? `<div class="alert bad"><span>⚠</span><span>${esc(S.summaryError)}</span>
      </div><button class="btn ghost" id="retrySummary">Try again</button>` : ''}
    ${s ? `
      <div class="alert good"><span>🧠</span><span><b>${esc(s.headline || 'Summary ready')}</b>
        Triage suggestion: ${esc(s.triage || 'Routine')} — ${esc(s.triageReason || '')}</span></div>
      <div class="sumcol">
        ${sec('Chief complaint', s.chiefComplaint)}
        ${sec('History of present illness', s.hpi)}
        ${sec('Past medical history', s.pastHistory)}
        ${sec('Surgical history', s.surgicalHistory)}
        ${sec('Current medicines', s.medications)}
        ${sec('Allergies', s.allergies)}
        ${sec('Family history', s.familyHistory)}
        ${sec('Personal history', s.personalHistory)}
        ${sec('Review of systems', s.reviewOfSystems)}
        ${sec('AYUSH observations', s.ayushObservations)}
      </div>
      ${Object.keys(S.ayush || {}).length ? `<div class="block" style="margin-top:16px"><h4>Ayurvedic assessment (AYUSH format)</h4>
        <ul>${Object.entries(S.ayush).map(([k, v]) => { const f = AYUSH_FIELDS.find(x => x[0] === k); return `<li><b>${esc(f ? f[1] : k)}:</b> ${esc(v)}</li>` }).join('')}</ul></div>` : ''}
      ${(s.reportFindings || []).length ? `<div class="block" style="margin-top:16px"><h4>Findings from your documents</h4>
        <ul>${s.reportFindings.map(f => `<li>${esc(f)}</li>`).join('')}</ul></div>` : ''}
      ${(s.redFlags || []).length ? `<div class="alert bad"><span>⚠</span><span><b>Red flags for the physician</b>
        ${s.redFlags.map(f => esc(f)).join('<br />')}</span></div>` : ''}
      ${(s.gaps || []).length ? `<div class="alert warn"><span>⚑</span><span><b>Still missing</b> ${s.gaps.map(esc).join(', ')}</span></div>` : ''}
      ${s.patientCopy ? `<div class="alert info"><span>💬</span><span>${esc(s.patientCopy)}</span></div>` : ''}
    ` : ''}
    <label class="field" style="margin-top:16px"><span>Anything you want to add in your own words?</span>
      <textarea id="noteBox" rows="3" placeholder="Optional">${esc(S.patientNote)}</textarea></label>
    <div class="alert warn"><span>⚠</span><span>AI-generated draft — physician verification required.</span></div>
    <div class="row">
      <button class="btn primary" id="sendToHospital" ${s ? '' : 'disabled'}>Send securely to the hospital</button>
      <button class="btn ghost" id="backToDocs">← Back to documents</button>
      <button class="btn quiet" id="printSummary">🖶 Print</button>
    </div>
  </div>`;
}

async function buildSummary() {
  S.summarising = true; S.summaryError = ''; S.summary = null; viewIntake();
  try {
    const out = await api('/api/summary', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        patient: S.patient, transcript: S.history, record: S.record,
        reports: S.reports, notes: S.notes, language: S.lang,
      }),
    });
    S.summary = out.summary;
    (S.summary.redFlags || []).forEach(f => { if (!S.urgent.includes(f)) S.urgent.push(f) });
  } catch (err) { S.summaryError = err.message }
  S.summarising = false; viewIntake();
}

async function sendToHospital() {
  S.patientNote = document.getElementById('noteBox')?.value || '';
  try {
    const out = await api('/api/records', {
      method: 'POST', headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        patient: S.patient, patientId: S.patientId, routing: S.routing, transcript: S.history, record: S.record, reports: S.reports, ayush: S.ayush,
        notes: S.notes, patientNote: S.patientNote, urgentReasons: S.urgent,
        summary: S.summary, consent: S.consent, language: S.lang,
      }),
    });
    S.submitted = out;
    S.step = 'done';
    viewIntake();
  } catch (err) {
    S.summaryError = err.message;
    viewIntake();
  }
}

/* --- 2f. done --- */
function stepDone() {
  const doc = (S.directory.doctors || []).find(d => d.doctorId === (S.submitted?.assignedDoctorId || S.routing.doctorId)) || null;
  const sentTo = `<div class="block" style="text-align:left;margin-top:18px">
    <h4>\ud83d\udce8 This report was sent to</h4>
    <div class="kv"><span>Doctor</span><b>${esc(S.submitted?.doctorName || doc?.name || S.routing.doctorId || 'Reception desk')}</b></div>
    ${(S.submitted?.specialty || doc?.specialty) ? `<div class="kv"><span>Specialty</span><b>${esc(S.submitted?.specialty || doc.specialty)}</b></div>` : ''}
    <div class="kv"><span>Hospital / clinic</span><b>${esc(S.submitted?.hospital || doc?.hospital || S.routing.hospital || '\u2014')}</b></div>
    ${(S.submitted?.opd || doc?.opd) ? `<div class="kv"><span>OPD timing</span><b>${esc(S.submitted?.opd || doc.opd)}</b></div>` : ''}
    <div class="kv"><span>Sent on</span><b>${esc(new Date(S.submitted?.submittedAt || Date.now()).toLocaleString())}</b></div>
    <div class="kv"><span>Status</span><b>${esc(S.submitted?.status || 'Awaiting physician review')}</b></div>
    <p class="tiny">Next time you log in with your patient ID, this visit, the doctor's name and their prescription will be waiting for you under \u201cPast visits\u201d.</p>
  </div>`;
  return `<div class="card rise" style="text-align:center">
    <div style="font-size:3rem">✅</div>
    <h2>Your history has been sent</h2>
    <p class="lead" style="margin:0 auto">Please show this token at the reception desk. Your doctor will verify everything before your consultation.</p>
    <h1 style="color:var(--deep);margin:18px 0">${esc(S.submitted?.token || 'T-000')}</h1>
    <p><b>Your patient ID: ${esc(S.submitted?.patientId || S.patientId)}</b></p><p class="tiny">Save this ID to restore reports on your next visit · Reference ${esc(S.submitted?.id || '')}</p>
    ${sentTo}
    <div class="row" style="justify-content:center;margin-top:18px">
      <button class="btn primary" id="restart">Start a new patient</button>
      <button class="btn quiet" id="toGate">Home</button>
      <button class="btn ghost" id="printSummary">🖶 Print my copy</button>
    </div>
  </div>`;
}

/* ---------------- step wiring ---------------- */
function on(id, handler, event = 'onclick') {
  const el = document.getElementById(id);
  if (el) el[event] = handler;
}

function wireStep() {
  on('toGate', () => { S.view = 'gate'; render() });
  on('idNext', submitIdentity);

  on('probYes', () => { S.historyAsk = 'yes'; S.step = 'consent'; S.consent = {}; viewIntake() });
  on('probNo', () => { S.historyAsk = 'no'; viewIntake() });
  on('readHistory', () => speak(`${S.patient.name || ''}, you have ${(S.visits || []).length} previous visit or visits saved with the identity ${S.patientId}. ${(S.visits || []).find(v => v.prescription) ? 'Your doctor has written a prescription for you, it is shown on the screen.' : ''} Do you have any problem today?`));
  on('ayushNext', () => { collectAyush(); S.step = 'documents'; viewIntake() });
  on('ayushSkip', () => { S.ayush = {}; S.step = 'documents'; viewIntake() });

  on('readAloud', () => speak('MediKiosk will ask you about your health, read the reports you upload, and prepare a summary for your doctor. AI never diagnoses and never prescribes. You can stop at any time.'));
  on('consentBack', () => { S.step = 'identify'; viewIntake() });
  on('consentNext', () => {
    ['collect', 'documents', 'share', 'ai'].forEach(id => { S.consent[id] = !!document.getElementById(id)?.checked });
    if (!S.consent.collect || !S.consent.share) {
      return alert('Consent for collecting your history and sharing it with your doctor is needed to continue.');
    }
    S.step = 'interview';
    S.transcript = [];
    S.history = [];
    viewIntake();
    nextTurn('');
  });

  on('mic', toggleMic);
  on('send', () => submitAnswer());
  on('repeat', () => speak(S.question));
  on('skipToDocs', () => { S.step = 'documents'; viewIntake() });
  const box = document.getElementById('answer');
  if (box) box.onkeydown = e => { if (e.key === 'Enter') submitAnswer() };
  document.querySelectorAll('[data-chip]').forEach(b => { b.onclick = () => submitAnswer(b.dataset.chip) });
  const talk = document.getElementById('talk');
  if (talk) talk.scrollTop = talk.scrollHeight;

  const drop = document.getElementById('drop');
  const file = document.getElementById('file');
  if (drop && file) {
    drop.onclick = () => file.click();
    file.onchange = () => handleFiles([...file.files]);
    drop.ondragover = e => { e.preventDefault(); drop.classList.add('over') };
    drop.ondragleave = () => drop.classList.remove('over');
    drop.ondrop = e => { e.preventDefault(); drop.classList.remove('over'); handleFiles([...e.dataTransfer.files]) };
  }
  document.querySelectorAll('[data-drop]').forEach(b => {
    b.onclick = () => { S.reports.splice(Number(b.dataset.drop), 1); viewIntake() };
  });
  on('backToTalk', () => { S.step = S.step === 'ayush' ? 'interview' : 'ayush'; viewIntake() });
  const syncRoute=()=>{S.routing.hospital=document.getElementById('routeHospital')?.value||'';S.routing.specialty=document.getElementById('routeSpecialty')?.value||'';S.routing.doctorId=document.getElementById('routeDoctor')?.value||''};
  on('routeHospital',()=>{syncRoute();viewIntake()},'onchange');
  on('routeSpecialty',()=>{syncRoute();S.routing.doctorId='';viewIntake()},'onchange');
  on('routeDoctor',syncRoute,'onchange');
  on('docsNext', () => { syncRoute(); if(!S.routing.doctorId) return alert('Please choose the doctor who should receive this report.'); S.step = 'review'; buildSummary() });

  on('retrySummary', buildSummary);
  on('backToDocs', () => { S.step = 'documents'; viewIntake() });
  on('sendToHospital', sendToHospital);
  on('printSummary', () => window.print());
  on('restart', () => {
    Object.assign(S, {
      step: 'identify', patient: {}, patientId:'', patientMode:'', consent: {}, transcript: [], history: [], record: {},
      question: '', questionEn: '', chips: [], section: '', progress: 0, empathy: '',
      clarifyCount: 0, notes: [], urgent: [], reports: [], summary: null, patientNote: '',
      submitted: null, idProblems: [], idMessage: '', ayush: {}, visits: [], historyAsk: '',
    });
    S.view='patientAccess'; render();
  });
}

/* ---------------- 3. doctor login ---------------- */
function viewDoctorLogin() {
  app.innerHTML = `<div class="card rise" style="max-width:460px;margin:40px auto">
    <span class="eyebrow">Hospital access</span>
    <h2>Doctor / staff sign in</h2>
    <p class="tiny">This console shows real patient submissions, so it is behind a staff PIN. The default PIN is <b>2026</b>; change it with the DOCTOR_PIN environment variable.</p>
    <label class="field"><span>Staff PIN</span><input id="pin" type="password" inputmode="numeric" autocomplete="off" /></label>
    <p class="err" id="pinErr"></p>
    <div class="row">
      <button class="btn primary block" id="pinGo">Open clinical console</button>
      <button class="btn ghost block" id="toGate">Back</button>
    </div>
  </div>`;
  const go = async () => {
    const pin = document.getElementById('pin').value;
    try {
      await api('/api/doctor/login', {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({pin})});
      S.view = 'doctor';
      renderDoctor();
    } catch (err) { document.getElementById('pinErr').textContent = err.message }
  };
  on('pinGo', go);
  on('toGate', () => { S.view = 'gate'; render() });
  const pin = document.getElementById('pin');
  pin.onkeydown = e => { if (e.key === 'Enter') go() };
  pin.focus();
}

/* ---------------- 4. doctor console ---------------- */
const TABS = [['queue', '🧾 Patient queue'], ['patient', '🧑‍⚕ Patient view'], ['documents', '📄 Documents'], ['analytics', '📈 Analytics'], ['assistant', '🧠 Ask the AI']];

function viewDoctor() { renderDoctor(false) }

async function renderDoctor(reload = true) {
  if (reload) {
    app.innerHTML = '<div class="card"><div class="skeleton"></div><div class="skeleton" style="width:70%"></div></div>';
    S.doc.loading = true; S.doc.error = '';
    try { S.doc.records = await api('/api/records' + (S.doc.current?.doctorId ? `?doctorId=${encodeURIComponent(S.doc.current.doctorId)}` : '')) } catch (err) { S.doc.error = err.message }
    S.doc.loading = false;
  }
  const d = S.doc;
  app.className = 'wrap wide';
  app.innerHTML = `<div class="shell">
    <nav class="side">
      ${d.current ? `<div class="doctor-mini"><b>${esc(d.current.name)}</b><span>${esc(d.current.specialty)}</span><small>${esc(d.current.doctorId)}</small></div>` : ''}
      <h5>Clinical</h5>
      ${TABS.map(([id, label]) => `<button data-tab="${id}" class="${d.tab === id ? 'on' : ''}">${label}</button>`).join('')}
      <h5>Session</h5>
      <button id="refresh">⟳ Refresh queue</button>
      <button id="toKiosk">← Patient kiosk</button>
    </nav>
    <div>
      ${d.error ? `<div class="alert bad"><span>⚠</span><span>${esc(d.error)}</span></div>` : ''}
      ${aiBanner()}
      <div id="docBody"></div>
    </div>
  </div>`;

  const body = {
    queue: docQueue, patient: docPatient, documents: docDocuments,
    analytics: docAnalytics, assistant: docAssistant,
  }[d.tab] || docQueue;
  document.getElementById('docBody').innerHTML = body();
  wireDoctor();
}

function triageTag(triage) {
  const cls = triage === 'Immediate' ? 'high' : triage === 'Priority' ? 'pos' : 'ok';
  return `<span class="tag ${cls}">${esc(triage || 'Routine')}</span>`;
}

function docQueue() {
  const q = S.doc.search.toLowerCase();
  const rows = S.doc.records.filter(r => !q || JSON.stringify(r).toLowerCase().includes(q));
  const stat = (value, label) => `<div class="stat rise"><b>${value}</b><span>${label}</span></div>`;
  const total = S.doc.records.length;
  const urgent = S.doc.records.filter(r => (r.urgentReasons || []).length || r.aiSummary?.triage === 'Immediate').length;
  const pending = S.doc.records.filter(r => r.status === 'Awaiting physician review').length;
  const docs = S.doc.records.reduce((s, r) => s + (r.reports || []).length, 0);

  return `<div class="grid g4" style="margin-bottom:18px">
    ${stat(total, 'Intakes received')}${stat(pending, 'Awaiting review')}${stat(urgent, 'Flagged urgent')}${stat(docs, 'Documents read')}
  </div>
  <div class="card rise">
    <div class="row" style="justify-content:space-between">
      <h2>Patient queue</h2>
      <input id="search" placeholder="Search token, complaint, finding…" style="padding:11px 15px;border-radius:999px;border:1px solid var(--line);min-width:260px" value="${esc(S.doc.search)}" />
    </div>
    ${rows.length ? `<table><thead><tr><th>Token</th><th>Patient</th><th>Age</th><th>Chief complaint</th><th>AI history</th><th>Docs</th><th>Triage</th><th>Status</th><th></th></tr></thead>
    <tbody>${rows.map(r => `<tr>
      <td><b style="color:var(--ink)">${esc(r.token)}</b></td>
      <td>${esc(r.patient?.name || 'Not given')}<br /><span class="tiny">${esc(r.patientId)}</span></td>
      <td>${esc(r.patient?.age || '—')} ${esc((r.patient?.gender || '').slice(0, 1))}</td>
      <td>${esc((r.aiSummary?.chiefComplaint || r.record?.chiefComplaint || 'Not recorded').slice(0, 70))}</td>
      <td>${(r.transcript || []).length} answers${r.aiSummary ? '<br /><span class="tag plum">AI summary</span>' : ''}</td>
      <td>${(r.reports || []).length}</td>
      <td>${triageTag(r.aiSummary?.triage)}</td>
      <td><span class="tag ${r.status === 'Awaiting physician review' ? 'pos' : 'ok'}">${esc(r.status)}</span></td>
      <td><button class="btn ghost" data-open="${esc(r.id)}">Open</button></td>
    </tr>`).join('')}</tbody></table>` : '<p class="tiny">No submissions yet. Complete a patient intake to see it here.</p>'}
  </div>`;
}

function docPatient() {
  const r = S.doc.records.find(x => x.id === S.doc.open) || S.doc.records[0];
  if (!r) return '<div class="card"><p class="tiny">No patient selected yet. Open one from the queue.</p></div>';
  const s = r.aiSummary;
  const block = (label, value) => `<div class="block"><h4>${label}</h4><p>${esc(value || 'Not reported')}</p></div>`;
  return `<div class="card rise">
    <div class="row" style="justify-content:space-between">
      <div><h2>${esc(r.patient?.name || 'Patient')} · ${esc(r.token)}</h2>
        <p class="tiny">${esc(r.patient?.age || '?')} year old ${esc(r.patient?.gender || '')} · ${esc(r.patient?.phone || 'no phone')} · submitted ${esc(new Date(r.submittedAt).toLocaleString())}</p></div>
      <div class="row">${triageTag(s?.triage)}<span class="tag grey">${esc(r.status)}</span></div>
    </div>
    <div class="alert warn"><span>⚠</span><span>AI must never autonomously diagnose or prescribe. The physician remains the final decision maker.</span></div>
    ${(r.urgentReasons || []).length ? `<div class="alert bad"><span>⚠</span><span><b>Red flags detected during intake</b> ${r.urgentReasons.map(esc).join(', ')}</span></div>` : ''}
    ${s ? `<div class="alert info"><span>🧠</span><span><b>${esc(s.headline || '')}</b>${esc(s.triageReason || '')}</span></div>
    <div class="sumcol">
      ${block('Chief complaint', s.chiefComplaint)}${block('History of present illness', s.hpi)}
      ${block('Past medical history', s.pastHistory)}${block('Surgical history', s.surgicalHistory)}
      ${block('Medications', s.medications)}${block('Allergies', s.allergies)}
      ${block('Family history', s.familyHistory)}${block('Personal history', s.personalHistory)}
      ${block('Review of systems', s.reviewOfSystems)}${block('AYUSH observations', s.ayushObservations)}
    </div>
    ${Object.keys(r.ayush || {}).length ? `<div class="block" style="margin-top:14px"><h4>Ayurvedic assessment (AYUSH format, patient reported)</h4>
      <ul>${Object.entries(r.ayush).map(([k, v]) => `<li><b>${esc(k)}:</b> ${esc(v)}</li>`).join('')}</ul></div>` : ''}
    ${(s.reportFindings || []).length ? `<div class="block" style="margin-top:14px"><h4>Report findings</h4><ul>${s.reportFindings.map(f => `<li>${esc(f)}</li>`).join('')}</ul></div>` : ''}
    ${(s.questionsForDoctor || []).length ? `<div class="block" style="margin-top:14px"><h4>Suggested areas to explore</h4><ul>${s.questionsForDoctor.map(f => `<li>${esc(f)}</li>`).join('')}</ul></div>` : ''}
    ${(s.gaps || []).length ? `<div class="alert warn"><span>⚑</span><span><b>Gaps in the history</b> ${s.gaps.map(esc).join(', ')}</span></div>` : ''}` : '<p class="tiny">No AI summary was stored for this intake.</p>'}

    <hr class="sep" />
    <h3>Interview transcript</h3>
    <div class="talk" style="max-height:none">${(r.transcript || []).map(x =>
      `<div class="msg ai"><span class="who">Asked</span>${esc(x.question)}</div><div class="msg me"><span class="who">Patient</span>${esc(x.answer)}</div>`).join('') || '<p class="tiny">No transcript.</p>'}</div>
    ${r.patientNote ? `<div class="alert info"><span>💬</span><span><b>In the patient's own words</b> ${esc(r.patientNote)}</span></div>` : ''}

    <hr class="sep" />
    <div class="grid g2">
      <label class="field"><span>Physician impression (your words, not AI)</span><textarea id="dx" rows="3">${esc(r.diagnosis || '')}</textarea></label>
      <label class="field"><span>Advice / notes · shown to the patient</span><textarea id="notes" rows="3">${esc(r.doctorNotes || '')}</textarea></label>
    </div>
    <label class="field"><span>Prescription · written by you, shown to the patient when they log in with their ID</span>
      <textarea id="rx" rows="5" placeholder="Tab. ... 1-0-1 after food for 5 days&#10;Syp. ... 10 ml at night&#10;Review after 7 days">${esc(r.prescription || '')}</textarea></label>
    <div class="row">
      <button class="btn primary" id="verify">✓ Verify and save</button>
      <button class="btn danger" id="reject">Reject the extraction</button>
      <button class="btn ghost" id="backQueue">← Back to queue</button>
    </div>
  </div>`;
}

function docDocuments() {
  const all = S.doc.records.flatMap(r => (r.reports || []).map(x => ({...x, token: r.token, name: r.patient?.name})));
  if (!all.length) return '<div class="card"><p class="tiny">No documents have been uploaded yet.</p></div>';
  return all.map((r, i) => `<div class="card rise" style="margin-bottom:16px">
    <div class="row" style="justify-content:space-between">
      <h3>${esc(r.documentName || 'Document')} <span class="tiny">· ${esc(r.token)} ${esc(r.name || '')}</span></h3>
      <span class="tag ${r.engine === 'ai' ? 'plum' : 'grey'}">${r.engine === 'ai' ? 'Read by AI' : 'OCR only'}</span>
    </div>
    <div class="grid g2">
      <div class="block"><h4>Text read from the file</h4><pre class="mono" style="white-space:pre-wrap;max-height:280px;overflow:auto">${esc((r.rawText || '').slice(0, 3000) || 'No text')}</pre></div>
      <div class="block"><h4>Structured extraction</h4>
        ${(r.labValues || []).map(v => `<div class="row" style="justify-content:space-between"><span>${esc(v.name)}</span><span><b>${esc(v.value)} ${esc(v.unit || '')}</b> <span class="tiny">${esc(v.status || '')}</span></span></div>`).join('') || '<p class="tiny">No numeric values.</p>'}
        ${(r.testResults || []).map(x => `<span class="tag ${/Positive|Reactive/i.test(x.result) ? 'pos' : 'ok'}">${esc(x.name)}: ${esc(x.result)}</span> `).join('')}
        ${r.summary ? `<p class="tiny" style="margin-top:8px">${esc(r.summary)}</p>` : ''}
      </div>
    </div>
  </div>`).join('');
}

function docAnalytics() {
  const recs = S.doc.records;
  if (!recs.length) return '<div class="card"><p class="tiny">Analytics appear once intakes are submitted.</p></div>';
  const bucket = {'0-17': 0, '18-35': 0, '36-55': 0, '56+': 0};
  recs.forEach(r => {
    const a = Number(r.patient?.age) || 0;
    bucket[a < 18 ? '0-17' : a < 36 ? '18-35' : a < 56 ? '36-55' : '56+']++;
  });
  const triage = {Routine: 0, Priority: 0, Immediate: 0};
  recs.forEach(r => { triage[r.aiSummary?.triage || 'Routine']++ });
  const langs = {};
  recs.forEach(r => { langs[r.language || 'en'] = (langs[r.language || 'en'] || 0) + 1 });
  const withDocs = recs.filter(r => (r.reports || []).length).length;

  return `<div class="grid g2">
    <div class="card rise"><h3>Age distribution</h3>${MK.bars(Object.entries(bucket))}</div>
    <div class="card rise"><h3>Triage suggestion</h3>${MK.donut(Object.entries(triage))}</div>
    <div class="card rise"><h3>Language used</h3>${MK.bars(Object.entries(langs))}</div>
    <div class="card rise"><h3>Intake quality</h3>
      <dl class="kv">
        <dt>Intakes</dt><dd>${recs.length}</dd>
        <dt>With documents</dt><dd>${withDocs}</dd>
        <dt>Average answers</dt><dd>${Math.round(recs.reduce((s, r) => s + (r.transcript || []).length, 0) / recs.length)}</dd>
        <dt>Verified by physician</dt><dd>${recs.filter(r => r.status !== 'Awaiting physician review').length}</dd>
      </dl>
    </div>
  </div>`;
}

function docAssistant() {
  const a = S.doc.answer;
  return `<div class="card rise">
    <span class="eyebrow">Clinical assistant</span>
    <h2>Ask the AI about today's queue</h2>
    <p class="tiny">It answers only from the submitted intakes. It will not diagnose or suggest treatment.</p>
    <div class="answerbar" style="max-width:none">
      <input id="askBox" placeholder="e.g. which patients have abnormal haemoglobin?" value="${esc(S.doc.ask)}" />
      <button class="btn primary" id="askGo" ${S.doc.asking ? 'disabled' : ''}>${S.doc.asking ? 'Thinking…' : 'Ask'}</button>
    </div>
    ${S.doc.askError ? `<div class="alert bad"><span>⚠</span><span>${esc(S.doc.askError)}</span></div>` : ''}
    ${a ? `<div class="alert info" style="margin-top:16px"><span>🧠</span><span>${esc(a.answer)}
      ${(a.tokens || []).length ? `<br /><b>Patients:</b> ${a.tokens.map(esc).join(', ')}` : ''}
      ${a.caution ? `<br /><span class="tiny">${esc(a.caution)}</span>` : ''}</span></div>` : ''}
  </div>`;
}

/* Settings shown to everyone on the home screen. No API keys here — the key
 * lives only in server/ai-key.mjs on the hospital server. */
const PREFS_KEY = 'medikiosk-prefs';

function loadPrefs() {
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(PREFS_KEY) || '{}') } catch {}
  return {theme: 'light', textSize: 'normal', autoRead: true, lang: 'en', ...saved};
}

function savePrefs(next) {
  S.prefs = {...S.prefs, ...next};
  try { localStorage.setItem(PREFS_KEY, JSON.stringify(S.prefs)) } catch {}
  applyPrefs();
}

function applyPrefs() {
  const p = S.prefs || loadPrefs();
  document.body.classList.toggle('dark', p.theme === 'dark');
  document.body.classList.toggle('high-contrast', p.theme === 'contrast');
  document.body.classList.toggle('large-font', p.textSize === 'large');
  document.body.classList.toggle('xlarge-font', p.textSize === 'xlarge');
}

function settingsPanel() {
  const p = S.prefs || loadPrefs();
  const pick = (name, value, label, current) =>
    `<button class="btn ${current === value ? 'primary' : 'ghost'}" data-pref="${name}" data-value="${value}">${label}</button>`;
  return `<div class="card rise">
    <div class="row" style="justify-content:space-between">
      <div><span class="eyebrow">Comfort</span><h2>Display and accessibility</h2></div>
    </div>
    <p class="tiny">Your choices are saved on this device only.</p>
    <div class="block"><h4>Appearance</h4><div class="row">
      ${pick('theme', 'light', 'Light mode', p.theme)}
      ${pick('theme', 'dark', 'Dark mode', p.theme)}
      ${pick('theme', 'contrast', 'High contrast mode', p.theme)}
    </div></div>
    <div class="block"><h4>Text size</h4><div class="row">
      ${pick('textSize', 'normal', 'Normal', p.textSize)}
      ${pick('textSize', 'large', 'Large', p.textSize)}
      ${pick('textSize', 'xlarge', 'Extra large', p.textSize)}
    </div></div>
    <div class="block"><h4>Language</h4>
      <label class="field"><span>Language</span><select id="setLang">
        ${MK.LANGS.map(([code, label]) => `<option value="${code}" ${S.lang === code ? 'selected' : ''}>${label}</option>`).join('')}
      </select></label>
      <p class="tiny">Changing the language translates the whole website and the AI answers in that language too.</p>
    </div>
    <div class="block"><h4>Voice and sound</h4>
      <label class="row" style="gap:10px"><input type="checkbox" id="setRead" ${p.autoRead ? 'checked' : ''} /><span>Read questions aloud automatically</span></label>
    </div>
  </div>`;
}

function wireSettings() {
  document.querySelectorAll('[data-pref]').forEach(b => {
    b.onclick = () => {
      savePrefs({[b.dataset.pref]: b.dataset.value});
      const host = document.getElementById('settingsHost');
      if (host) { host.innerHTML = settingsPanel(); wireSettings(); retranslate() }
    };
  });
  const sel = document.getElementById('setLang');
  if (sel) sel.onchange = () => {
    S.lang = sel.value;
    savePrefs({lang: sel.value});
    const head = document.getElementById('lang');
    if (head) head.value = sel.value;
    S.openSettings = true;
    render();
  };
  const read = document.getElementById('setRead');
  if (read) read.onchange = () => savePrefs({autoRead: read.checked});
}

/* Kept so older buttons that point at the settings drawer keep working. */
function wireSettingsShortcut() {
  on('goSettings', () => {
    S.openSettings = true;
    S.view = 'gate';
    app.className = 'wrap';
    render();
    document.getElementById('setwrap')?.scrollIntoView({behavior: 'smooth', block: 'center'});
  });
}

function wireDoctor() {
  document.querySelectorAll('[data-tab]').forEach(b => {
    b.onclick = () => { S.doc.tab = b.dataset.tab; renderDoctor(false) };
  });
  on('refresh', () => renderDoctor(true));
  on('toKiosk', () => { S.view = 'gate'; app.className = 'wrap'; render() });

  const search = document.getElementById('search');
  if (search) search.oninput = () => { S.doc.search = search.value; const at = search.selectionStart; renderDoctor(false); const el = document.getElementById('search'); if (el) { el.focus(); el.setSelectionRange(at, at) } };
  document.querySelectorAll('[data-open]').forEach(b => {
    b.onclick = () => { S.doc.open = b.dataset.open; S.doc.tab = 'patient'; renderDoctor(false) };
  });
  on('backQueue', () => { S.doc.tab = 'queue'; renderDoctor(false) });

  const saveReview = async status => {
    const r = S.doc.records.find(x => x.id === S.doc.open) || S.doc.records[0];
    if (!r) return;
    try {
      await api('/api/records/notes', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          id: r.id, status,
          diagnosis: document.getElementById('dx')?.value || '',
          doctorNotes: document.getElementById('notes')?.value || '',
          prescription: document.getElementById('rx')?.value || '',
        }),
      });
      renderDoctor(true);
    } catch (err) { S.doc.error = err.message; renderDoctor(false) }
  };
  on('verify', () => saveReview('Reviewed by physician'));
  on('reject', () => saveReview('Extraction rejected — re-verify manually'));

  const askGo = async () => {
    S.doc.ask = document.getElementById('askBox')?.value || '';
    if (!S.doc.ask.trim()) return;
    S.doc.asking = true; S.doc.askError = ''; renderDoctor(false);
    try {
      S.doc.answer = await api('/api/doctor/ask', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({question: S.doc.ask}),
      });
    } catch (err) { S.doc.askError = err.message }
    S.doc.asking = false; renderDoctor(false);
  };
  on('askGo', askGo);
  const askBox = document.getElementById('askBox');
  if (askBox) askBox.onkeydown = e => { if (e.key === 'Enter') askGo() };

}

/* ---------------- header & boot ---------------- */
function wireHeader() {
  const lang = document.getElementById('lang');
  lang.innerHTML = MK.LANGS.map(([code, label]) => `<option value="${code}">${label}</option>`).join('');
  lang.value = S.lang;
  lang.onchange = () => {
    S.lang = lang.value;
    savePrefs({lang: lang.value});
    document.getElementById('tagline').textContent = t('tagline');
    render();
  };
  document.getElementById('font').onclick = e => {
    const order = ['normal', 'large', 'xlarge'];
    const next = order[(order.indexOf(S.prefs.textSize) + 1) % order.length];
    savePrefs({textSize: next});
    e.currentTarget.classList.toggle('on', next !== 'normal');
  };
  document.getElementById('contrast').onclick = e => {
    const order = ['light', 'dark', 'contrast'];
    const next = order[(order.indexOf(S.prefs.theme) + 1) % order.length];
    savePrefs({theme: next});
    e.currentTarget.classList.toggle('on', next !== 'light');
  };
  const gear = document.getElementById('gear');
  if (gear) gear.onclick = () => {
    S.openSettings = true;
    S.view = 'gate';
    app.className = 'wrap';
    render();
    document.getElementById('setwrap')?.scrollIntoView({behavior: 'smooth', block: 'center'});
  };
  document.getElementById('help').onclick = () => {
    alert('MediKiosk help\n\n1. Choose patient or hospital access.\n2. Patients: fill your details, agree to the consent, then answer the spoken questions. Tap the microphone or type.\n3. Upload any old report or prescription. The AI reads it and explains it.\n4. Check the summary and send it to the hospital. Keep your token.\n5. Staff: sign in with the PIN to review, verify and add notes.\n\nNothing here is a diagnosis. Your doctor decides everything.');
  };
  document.getElementById('home').onclick = () => {
    S.view = 'gate'; app.className = 'wrap'; render();
  };
}

(async function boot() {
  S.prefs = loadPrefs();
  if (S.prefs.lang) S.lang = S.prefs.lang;
  applyPrefs();
  wireHeader();
  const observer = new MutationObserver(() => retranslate());
  observer.observe(document.body, {childList: true, subtree: true});
  render();
  await checkHealth();
  render();
  setInterval(checkHealth, 30000);
})();
